<?php
/**
 * Archivo de depuración para encontrar errores
 */

// Mostrar todos los errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

echo "<h1>🔍 Depuración de Indice SaaS</h1>";
echo "<p>Fecha: " . date('Y-m-d H:i:s') . "</p>";

echo "<h2>1. Verificando archivos básicos...</h2>";

// Verificar config.php
echo "<h3>📁 config.php</h3>";
try {
    require_once 'config.php';
    echo "✅ config.php cargado correctamente<br>";
    
    // Verificar funciones básicas
    if (function_exists('checkAuth')) {
        echo "✅ Función checkAuth() disponible<br>";
    } else {
        echo "❌ Función checkAuth() NO disponible<br>";
    }
    
    if (function_exists('getDB')) {
        echo "✅ Función getDB() disponible<br>";
    } else {
        echo "❌ Función getDB() NO disponible<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Error en config.php: " . $e->getMessage() . "<br>";
}

echo "<h3>📁 Verificando base de datos</h3>";
try {
    $db = getDB();
    echo "✅ Conexión a base de datos exitosa<br>";
    
    // Verificar tabla users
    $stmt = $db->query("SHOW TABLES LIKE 'users'");
    if ($stmt->fetch()) {
        echo "✅ Tabla 'users' existe<br>";
    } else {
        echo "❌ Tabla 'users' NO existe<br>";
    }
    
    // Verificar tabla companies
    $stmt = $db->query("SHOW TABLES LIKE 'companies'");
    if ($stmt->fetch()) {
        echo "✅ Tabla 'companies' existe<br>";
    } else {
        echo "❌ Tabla 'companies' NO existe<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Error en base de datos: " . $e->getMessage() . "<br>";
}

echo "<h3>🔐 Verificando sesión</h3>";
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "✅ Sesión activa<br>";
    echo "📝 Variables de sesión:<br>";
    echo "<pre>";
    print_r($_SESSION);
    echo "</pre>";
} else {
    echo "❌ No hay sesión activa<br>";
}

echo "<h3>📧 Verificando sistema de email</h3>";
try {
    if (file_exists('../admin/email_config.php')) {
        include '../admin/email_config.php';
        echo "✅ email_config.php cargado<br>";
        
        if (function_exists('sendInvitationEmail')) {
            echo "✅ Función sendInvitationEmail() disponible<br>";
        } else {
            echo "❌ Función sendInvitationEmail() NO disponible<br>";
        }
    } else {
        echo "❌ Archivo email_config.php no encontrado<br>";
    }
} catch (Exception $e) {
    echo "❌ Error en sistema de email: " . $e->getMessage() . "<br>";
}

echo "<h3>🔔 Verificando componente de notificaciones</h3>";
try {
    if (file_exists('../components/navbar_notifications.php')) {
        echo "✅ Archivo navbar_notifications.php existe<br>";
        
        // Intentar incluir
        ob_start();
        include '../components/navbar_notifications.php';
        $output = ob_get_clean();
        
        if (strlen($output) > 0) {
            echo "✅ Componente se ejecutó (genera " . strlen($output) . " caracteres)<br>";
        } else {
            echo "⚠️ Componente se ejecutó pero no genera output<br>";
        }
    } else {
        echo "❌ Archivo navbar_notifications.php NO existe<br>";
    }
} catch (Exception $e) {
    echo "❌ Error en componente notificaciones: " . $e->getMessage() . "<br>";
    echo "📍 Archivo: " . $e->getFile() . "<br>";
    echo "📍 Línea: " . $e->getLine() . "<br>";
}

echo "<h2>🏁 Depuración completada</h2>";
echo "<p><a href='../companies/'>🔙 Volver a companies</a></p>";
?>
