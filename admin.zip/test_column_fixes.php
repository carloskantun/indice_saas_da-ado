<?php
// Final test for database column fixes
require_once 'config.php';

echo "🔧 Testing Database Column Fixes\n";
echo "=================================\n\n";

try {
    $db = getDB();
    
    // Test 1: Check companies table structure
    echo "1. Checking companies table structure...\n";
    $stmt = $db->query("DESCRIBE companies");
    $columns = $stmt->fetchAll();
    
    $has_name = false;
    $has_nombre = false;
    
    foreach ($columns as $column) {
        if ($column['Field'] === 'name') $has_name = true;
        if ($column['Field'] === 'nombre') $has_nombre = true;
    }
    
    echo "   - 'name' column: " . ($has_name ? '✅ EXISTS' : '❌ MISSING') . "\n";
    echo "   - 'nombre' column: " . ($has_nombre ? '✅ EXISTS' : '❌ MISSING') . "\n";
    
    // Test 2: Test SELECT query with correct column
    echo "\n2. Testing SELECT queries...\n";
    if ($has_nombre) {
        try {
            $stmt = $db->query("SELECT id, nombre FROM companies LIMIT 1");
            echo "   ✅ SELECT with 'nombre' works\n";
        } catch (Exception $e) {
            echo "   ❌ SELECT with 'nombre' failed: " . $e->getMessage() . "\n";
        }
    }
    
    if ($has_name) {
        try {
            $stmt = $db->query("SELECT id, name FROM companies LIMIT 1");
            echo "   ✅ SELECT with 'name' works\n";
        } catch (Exception $e) {
            echo "   ❌ SELECT with 'name' failed: " . $e->getMessage() . "\n";
        }
    }
    
    // Test 3: Test files that were giving errors
    echo "\n3. Testing problematic file patterns...\n";
    
    // Test companies/invitations.php pattern
    try {
        $stmt = $db->prepare("SELECT nombre FROM companies WHERE id = ?");
        echo "   ✅ companies/invitations.php query pattern works\n";
    } catch (Exception $e) {
        echo "   ❌ companies/invitations.php query failed: " . $e->getMessage() . "\n";
    }
    
    // Test notifications/index.php pattern
    try {
        $stmt = $db->prepare("SELECT DISTINCT uc.company_id, c.nombre FROM user_companies uc JOIN companies c ON uc.company_id = c.id WHERE uc.user_id = ?");
        echo "   ✅ notifications/index.php query pattern works\n";
    } catch (Exception $e) {
        echo "   ❌ notifications/index.php query failed: " . $e->getMessage() . "\n";
    }
    
    echo "\n🎉 All tests completed!\n";
    echo "\nRecommendation: ";
    if ($has_nombre && !$has_name) {
        echo "✅ Perfect! Database uses 'nombre' consistently.\n";
    } else if ($has_name && !$has_nombre) {
        echo "⚠️  Database uses 'name'. You may need to update queries to use 'name' instead of 'nombre'.\n";
    } else if ($has_name && $has_nombre) {
        echo "⚠️  Database has BOTH columns. Consider consolidating to one.\n";
    } else {
        echo "❌ No name/nombre column found! Database may need to be created.\n";
    }
    
} catch (Exception $e) {
    echo "❌ Database connection error: " . $e->getMessage() . "\n";
    echo "\nPlease check your .env file and database configuration.\n";
}
?>
