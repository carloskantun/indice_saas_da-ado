<?php
require_once 'indice-produccion/conexion.php';
require_once 'includes/notifications.php';

try {
    $db = getDB();
    
    echo "Inicializando base de datos para SaaS completo...\n";
    
    // 1. Crear tabla de notificaciones
    echo "Creando tabla de notificaciones...\n";
    createNotificationsTable();
    
    // 2. Verificar y actualizar tabla de empresas para incluir plan_id
    echo "Verificando estructura de tabla companies...\n";
    $stmt = $db->query("SHOW COLUMNS FROM companies LIKE 'plan_id'");
    if (!$stmt->fetch()) {
        echo "Agregando columna plan_id a tabla companies...\n";
        $db->exec("ALTER TABLE companies ADD COLUMN plan_id INT DEFAULT 1 AFTER id");
        $db->exec("ALTER TABLE companies ADD FOREIGN KEY (plan_id) REFERENCES plans(id)");
    }
    
    // 3. Verificar que existe la tabla de planes con datos
    echo "Verificando tabla de planes...\n";
    $stmt = $db->query("SELECT COUNT(*) FROM plans WHERE status = 'active'");
    $plan_count = $stmt->fetchColumn();
    
    if ($plan_count == 0) {
        echo "Insertando planes por defecto...\n";
        $db->exec("
            INSERT INTO plans (name, description, price, users_max, businesses_max, units_max, storage_max_mb, features, status) VALUES
            ('Gratuito', 'Plan básico gratuito con funcionalidades limitadas', 0.00, 5, 2, 10, 100, '[\"basic_modules\"]', 'active'),
            ('Premium', 'Plan premium con todas las funcionalidades', 29.99, -1, -1, -1, 1000, '[\"basic_modules\", \"premium_modules\", \"advanced_reports\", \"export_data\"]', 'active'),
            ('Enterprise', 'Plan empresarial para organizaciones grandes', 99.99, -1, -1, -1, -1, '[\"basic_modules\", \"premium_modules\", \"advanced_reports\", \"export_data\", \"custom_branding\", \"priority_support\"]', 'active')
        ");
    }
    
    // 4. Actualizar empresas existentes para tener un plan asignado
    echo "Asignando plan gratuito a empresas sin plan...\n";
    $db->exec("UPDATE companies SET plan_id = 1 WHERE plan_id IS NULL OR plan_id = 0");
    
    // 5. Verificar estructura de user_companies para nivel
    echo "Verificando estructura de tabla user_companies...\n";
    $stmt = $db->query("SHOW COLUMNS FROM user_companies LIKE 'nivel'");
    if (!$stmt->fetch()) {
        echo "Agregando columna nivel a tabla user_companies...\n";
        $db->exec("ALTER TABLE user_companies ADD COLUMN nivel INT DEFAULT 1 AFTER role");
        // Convertir roles existentes a niveles
        $db->exec("UPDATE user_companies SET nivel = 3 WHERE role IN ('admin', 'superadmin', 'root')");
        $db->exec("UPDATE user_companies SET nivel = 2 WHERE role = 'moderator'");
        $db->exec("UPDATE user_companies SET nivel = 1 WHERE role = 'user' OR nivel = 0");
    }
    
    // 6. Crear algunas notificaciones de ejemplo (solo si no hay ninguna)
    echo "Verificando notificaciones de ejemplo...\n";
    $stmt = $db->query("SELECT COUNT(*) FROM notifications");
    $notification_count = $stmt->fetchColumn();
    
    if ($notification_count == 0) {
        echo "Creando notificaciones de ejemplo...\n";
        
        // Obtener primera empresa y usuario
        $stmt = $db->query("SELECT id FROM companies LIMIT 1");
        $company_id = $stmt->fetchColumn();
        
        $stmt = $db->query("SELECT id FROM users LIMIT 1");
        $user_id = $stmt->fetchColumn();
        
        if ($company_id && $user_id) {
            $db->prepare("
                INSERT INTO notifications (company_id, user_id, type, title, message, status, created_at) 
                VALUES (?, ?, 'welcome', 'Bienvenido al Sistema', 'Gracias por registrarte en nuestro sistema SaaS. Explora todas las funcionalidades disponibles.', 'unread', NOW())
            ")->execute([$company_id, $user_id]);
        }
    }
    
    // 7. Crear índices para optimización
    echo "Creando índices de optimización...\n";
    try {
        $db->exec("CREATE INDEX IF NOT EXISTS idx_notifications_company_user ON notifications(company_id, user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_notifications_status ON notifications(status)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_companies_plan ON companies(plan_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_user_companies_nivel ON user_companies(nivel)");
    } catch (Exception $e) {
        echo "Algunos índices ya existían o no se pudieron crear: " . $e->getMessage() . "\n";
    }
    
    echo "\n=== RESUMEN DE INICIALIZACIÓN ===\n";
    
    // Mostrar estadísticas
    $stmt = $db->query("SELECT COUNT(*) FROM plans WHERE status = 'active'");
    echo "Planes activos: " . $stmt->fetchColumn() . "\n";
    
    $stmt = $db->query("SELECT COUNT(*) FROM companies");
    echo "Empresas registradas: " . $stmt->fetchColumn() . "\n";
    
    $stmt = $db->query("SELECT COUNT(*) FROM users");
    echo "Usuarios registrados: " . $stmt->fetchColumn() . "\n";
    
    $stmt = $db->query("SELECT COUNT(*) FROM notifications");
    echo "Notificaciones en sistema: " . $stmt->fetchColumn() . "\n";
    
    $stmt = $db->query("
        SELECT p.name, COUNT(c.id) as company_count 
        FROM plans p 
        LEFT JOIN companies c ON p.id = c.plan_id 
        WHERE p.status = 'active'
        GROUP BY p.id, p.name
    ");
    
    echo "\nDistribución por planes:\n";
    while ($row = $stmt->fetch()) {
        echo "- " . $row['name'] . ": " . $row['company_count'] . " empresas\n";
    }
    
    echo "\n✅ Inicialización completada exitosamente!\n";
    echo "\nFuncionalidades disponibles:\n";
    echo "- ✅ Registro con selección de planes\n";
    echo "- ✅ Sistema de invitaciones con fallback a notificaciones\n";
    echo "- ✅ Restricciones basadas en planes\n";
    echo "- ✅ Panel de notificaciones interno\n";
    echo "- ✅ Widgets de uso de plan\n";
    echo "- ✅ Aceptación de invitaciones desde el sistema\n";
    
} catch (Exception $e) {
    echo "❌ Error durante la inicialización: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
