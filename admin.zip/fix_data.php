<?php
/**
 * Script para verificar y crear datos básicos necesarios
 */
require_once 'config.php';

$db = getDB();

echo "<h1>🔧 Verificación y Reparación de Datos</h1>";

try {
    // 1. Verificar que existe el usuario root
    echo "<h3>1. Verificando usuario root...</h3>";
    $stmt = $db->prepare("SELECT * FROM users WHERE email = 'root@localhost'");
    $stmt->execute();
    $rootUser = $stmt->fetch();
    
    if ($rootUser) {
        echo "<p>✅ Usuario root encontrado: ID " . $rootUser['id'] . "</p>";
        $rootUserId = $rootUser['id'];
    } else {
        echo "<p>❌ Usuario root no encontrado. Creando...</p>";
        
        $stmt = $db->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->execute(['Root User', 'root@localhost', password_hash('root123', PASSWORD_DEFAULT)]);
        $rootUserId = $db->lastInsertId();
        echo "<p>✅ Usuario root creado con ID: $rootUserId</p>";
    }
    
    // 2. Verificar empresas
    echo "<h3>2. Verificando empresas...</h3>";
    $stmt = $db->query("SELECT COUNT(*) FROM companies");
    $companyCount = $stmt->fetchColumn();
    echo "<p>📊 Total de empresas: $companyCount</p>";
    
    if ($companyCount == 0) {
        echo "<p>⚠️ No hay empresas. Creando empresa demo...</p>";
        
        $stmt = $db->prepare("INSERT INTO companies (name, description, status) VALUES (?, ?, ?)");
        $stmt->execute(['Empresa Demo', 'Empresa de demostración', 'active']);
        $demoCompanyId = $db->lastInsertId();
        echo "<p>✅ Empresa demo creada con ID: $demoCompanyId</p>";
        
        // Asignar empresa al usuario root
        $stmt = $db->prepare("INSERT INTO user_companies (user_id, company_id, role) VALUES (?, ?, ?)");
        $stmt->execute([$rootUserId, $demoCompanyId, 'admin']);
        echo "<p>✅ Empresa asignada al usuario root como admin</p>";
    }
    
    // 3. Verificar relación user_companies para root
    echo "<h3>3. Verificando empresas del usuario root...</h3>";
    $stmt = $db->prepare("
        SELECT c.*, uc.role 
        FROM companies c 
        INNER JOIN user_companies uc ON c.id = uc.company_id 
        WHERE uc.user_id = ?
    ");
    $stmt->execute([$rootUserId]);
    $rootCompanies = $stmt->fetchAll();
    
    if (count($rootCompanies) > 0) {
        echo "<p>✅ El usuario root tiene " . count($rootCompanies) . " empresa(s):</p>";
        echo "<ul>";
        foreach ($rootCompanies as $company) {
            echo "<li>" . htmlspecialchars($company['name']) . " (Rol: " . $company['role'] . ")</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>❌ El usuario root no tiene empresas asignadas. Corrigiendo...</p>";
        
        // Obtener la primera empresa disponible
        $stmt = $db->query("SELECT id, name FROM companies LIMIT 1");
        $firstCompany = $stmt->fetch();
        
        if ($firstCompany) {
            $stmt = $db->prepare("INSERT INTO user_companies (user_id, company_id, role) VALUES (?, ?, ?)");
            $stmt->execute([$rootUserId, $firstCompany['id'], 'admin']);
            echo "<p>✅ Usuario root asignado a empresa: " . htmlspecialchars($firstCompany['name']) . "</p>";
        } else {
            echo "<p>❌ No hay empresas disponibles para asignar</p>";
        }
    }
    
    // 4. Verificar estructura de tablas necesarias
    echo "<h3>4. Verificando estructura de tablas...</h3>";
    $requiredTables = ['users', 'companies', 'user_companies', 'plans', 'modules'];
    
    $stmt = $db->query("SHOW TABLES");
    $existingTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($requiredTables as $table) {
        if (in_array($table, $existingTables)) {
            echo "<p>✅ Tabla '$table' existe</p>";
        } else {
            echo "<p>❌ Tabla '$table' falta</p>";
        }
    }
    
    echo "<h3>✅ Verificación completada</h3>";
    echo "<p><a href='companies/index.php' class='btn btn-primary'>Ir a Companies</a></p>";
    echo "<p><a href='companies/simple_test.php' class='btn btn-secondary'>Test Simple</a></p>";
    echo "<p><a href='debug.php' class='btn btn-info'>Debug General</a></p>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h4>❌ Error:</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Archivo: " . $e->getFile() . "</p>";
    echo "<p>Línea: " . $e->getLine() . "</p>";
    echo "</div>";
}
?>
