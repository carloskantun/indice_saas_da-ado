<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Sistema de Invitaciones</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .test-section { margin-bottom: 30px; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        .info { color: #17a2b8; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .status-ok::before { content: "✅ "; }
        .status-error::before { content: "❌ "; }
        .status-warning::before { content: "⚠️ "; }
        .status-info::before { content: "ℹ️ "; }
    </style>
</head>
<body>

<h1>🎯 Test Sistema de Invitaciones</h1>
<p class="info">Este script valida que la estructura de base de datos y las funcionalidades principales del sistema de invitaciones estén funcionando correctamente.</p>

<?php
require_once 'config.php';

$tests = [];
$errors = [];

try {
    $db = getDB();
    $tests[] = ['success', 'Conexión a base de datos establecida'];
    
    // Test 1: Validación de estructura
    echo '<div class="test-section">';
    echo '<h2>📋 Validación de Estructura</h2>';
    
    try {
        $stmt = $db->query("DESCRIBE user_invitations");
        $columns = $stmt->fetchAll();
        
        $required_columns = [
            'id' => 'ID de la invitación',
            'email' => 'Email del invitado',
            'company_id' => 'ID de la empresa',
            'role' => 'Rol asignado',
            'token' => 'Token de validación',
            'status' => 'Estado de la invitación',
            'sent_by' => 'Usuario que envió',
            'sent_date' => 'Fecha de envío',
            'expiration_date' => 'Fecha de expiración',
            'accepted_date' => 'Fecha de aceptación'
        ];
        
        $existing_columns = [];
        foreach ($columns as $column) {
            $existing_columns[] = $column['Field'];
        }
        
        echo '<table border="1" style="width:100%; border-collapse: collapse; margin-top: 10px;">';
        echo '<tr><th>Columna</th><th>Descripción</th><th>Estado</th></tr>';
        
        foreach ($required_columns as $col => $desc) {
            $exists = in_array($col, $existing_columns);
            $status = $exists ? 'status-ok success' : 'status-error error';
            echo "<tr><td>$col</td><td>$desc</td><td class='$status'>" . ($exists ? 'Existe' : 'Falta') . "</td></tr>";
            
            if (!$exists) {
                $errors[] = "Falta la columna '$col' en la tabla user_invitations";
            }
        }
        echo '</table>';
        
        $tests[] = ['success', 'Tabla user_invitations validada'];
        
    } catch (Exception $e) {
        $tests[] = ['error', 'Error validando estructura: ' . $e->getMessage()];
        $errors[] = $e->getMessage();
    }
    
    echo '</div>';
    
    // Test 2: Validación de Queries
    echo '<div class="test-section">';
    echo '<h2>🧪 Test de Queries</h2>';
    
    $queries_test = [
        'Lista de invitaciones' => "
            SELECT i.*, u.name as inviter_name 
            FROM user_invitations i
            LEFT JOIN users u ON i.sent_by = u.id
            WHERE i.company_id = 1 
            ORDER BY i.sent_date DESC
            LIMIT 5
        ",
        'Verificación de membresía' => "
            SELECT u.id, u.name
            FROM users u 
            INNER JOIN user_companies uc ON u.id = uc.user_id 
            WHERE u.email = 'admin@indiceapp.com' AND uc.company_id = 1
        ",
        'Invitación pendiente' => "
            SELECT id FROM user_invitations 
            WHERE email = 'test@example.com' AND company_id = 1 AND status = 'pending' AND expiration_date > NOW()
        ",
        'Validación de token' => "
            SELECT * FROM user_invitations 
            WHERE token = 'test_token' AND email = 'test@example.com' AND status = 'pending' AND expiration_date > NOW()
        "
    ];
    
    echo '<table border="1" style="width:100%; border-collapse: collapse; margin-top: 10px;">';
    echo '<tr><th>Query</th><th>Estado</th><th>Detalles</th></tr>';
    
    foreach ($queries_test as $name => $query) {
        try {
            $stmt = $db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetchAll();
            echo "<tr><td>$name</td><td class='status-ok success'>OK</td><td>Ejecutada correctamente</td></tr>";
            $tests[] = ['success', "Query '$name' ejecutada correctamente"];
        } catch (Exception $e) {
            echo "<tr><td>$name</td><td class='status-error error'>Error</td><td>" . htmlspecialchars($e->getMessage()) . "</td></tr>";
            $tests[] = ['error', "Query '$name' falló: " . $e->getMessage()];
            $errors[] = "Query '$name': " . $e->getMessage();
        }
    }
    echo '</table>';
    echo '</div>';
    
    // Test 3: Estadísticas
    echo '<div class="test-section">';
    echo '<h2>📊 Estadísticas del Sistema</h2>';
    
    try {
        $stats = [];
        
        $stmt = $db->query("SELECT COUNT(*) FROM user_invitations");
        $stats['total'] = $stmt->fetchColumn();
        
        $stmt = $db->query("SELECT COUNT(*) FROM user_invitations WHERE status = 'pending'");
        $stats['pending'] = $stmt->fetchColumn();
        
        $stmt = $db->query("SELECT COUNT(*) FROM user_invitations WHERE status = 'accepted'");
        $stats['accepted'] = $stmt->fetchColumn();
        
        $stmt = $db->query("SELECT COUNT(*) FROM user_invitations WHERE expiration_date < NOW() AND status = 'pending'");
        $stats['expired'] = $stmt->fetchColumn();
        
        echo '<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-top: 15px;">';
        echo '<div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">';
        echo '<h3 style="margin: 0; color: #495057;">📈 Total</h3>';
        echo '<p style="font-size: 24px; margin: 5px 0; color: #007bff;">' . $stats['total'] . '</p>';
        echo '</div>';
        
        echo '<div style="text-align: center; padding: 15px; background: #fff3cd; border-radius: 8px;">';
        echo '<h3 style="margin: 0; color: #856404;">⏳ Pendientes</h3>';
        echo '<p style="font-size: 24px; margin: 5px 0; color: #856404;">' . $stats['pending'] . '</p>';
        echo '</div>';
        
        echo '<div style="text-align: center; padding: 15px; background: #d4edda; border-radius: 8px;">';
        echo '<h3 style="margin: 0; color: #155724;">✅ Aceptadas</h3>';
        echo '<p style="font-size: 24px; margin: 5px 0; color: #155724;">' . $stats['accepted'] . '</p>';
        echo '</div>';
        
        echo '<div style="text-align: center; padding: 15px; background: #f8d7da; border-radius: 8px;">';
        echo '<h3 style="margin: 0; color: #721c24;">⌛ Expiradas</h3>';
        echo '<p style="font-size: 24px; margin: 5px 0; color: #721c24;">' . $stats['expired'] . '</p>';
        echo '</div>';
        echo '</div>';
        
        $tests[] = ['success', 'Estadísticas obtenidas correctamente'];
        
    } catch (Exception $e) {
        echo '<p class="error">Error obteniendo estadísticas: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $tests[] = ['error', 'Error obteniendo estadísticas: ' . $e->getMessage()];
    }
    
    echo '</div>';
    
    // Test 4: Usuarios del sistema
    echo '<div class="test-section">';
    echo '<h2>👥 Usuarios del Sistema</h2>';
    
    try {
        $stmt = $db->query("
            SELECT u.email, u.name, COUNT(uc.company_id) as companies_count
            FROM users u
            LEFT JOIN user_companies uc ON u.id = uc.user_id
            GROUP BY u.id
            LIMIT 10
        ");
        $users = $stmt->fetchAll();
        
        if (count($users) > 0) {
            echo '<table border="1" style="width:100%; border-collapse: collapse; margin-top: 10px;">';
            echo '<tr><th>Email</th><th>Nombre</th><th>Empresas</th></tr>';
            
            foreach ($users as $user) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($user['email']) . '</td>';
                echo '<td>' . htmlspecialchars($user['name']) . '</td>';
                echo '<td>' . $user['companies_count'] . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        } else {
            echo '<p class="warning">No se encontraron usuarios en el sistema.</p>';
        }
        
        $tests[] = ['success', 'Lista de usuarios obtenida'];
        
    } catch (Exception $e) {
        echo '<p class="error">Error obteniendo usuarios: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $tests[] = ['error', 'Error obteniendo usuarios: ' . $e->getMessage()];
    }
    
    echo '</div>';
    
} catch (Exception $e) {
    $tests[] = ['error', 'Error de conexión a base de datos: ' . $e->getMessage()];
    $errors[] = 'Conexión DB: ' . $e->getMessage();
}

// Resumen final
echo '<div class="test-section">';
echo '<h2>📋 Resumen de Tests</h2>';

$success_count = 0;
$error_count = 0;

echo '<ul>';
foreach ($tests as $test) {
    $class = $test[0] === 'success' ? 'status-ok success' : 'status-error error';
    echo "<li class='$class'>{$test[1]}</li>";
    
    if ($test[0] === 'success') {
        $success_count++;
    } else {
        $error_count++;
    }
}
echo '</ul>';

echo '<div style="margin-top: 20px; padding: 15px; border-radius: 8px; background: ' . 
     ($error_count === 0 ? '#d4edda' : '#f8d7da') . ';">';

if ($error_count === 0) {
    echo '<h3 style="color: #155724; margin: 0;">🎉 ¡Todos los tests pasaron!</h3>';
    echo '<p style="color: #155724;">El sistema de invitaciones está funcionando correctamente.</p>';
} else {
    echo '<h3 style="color: #721c24; margin: 0;">⚠️ Se encontraron ' . $error_count . ' errores</h3>';
    echo '<p style="color: #721c24;">Revisa los errores arriba para corregir los problemas.</p>';
}

echo "<p><strong>Tests exitosos:</strong> $success_count | <strong>Tests fallidos:</strong> $error_count</p>";
echo '</div>';

if (count($errors) > 0) {
    echo '<h3>🔧 Errores que requieren atención:</h3>';
    echo '<ul>';
    foreach ($errors as $error) {
        echo '<li class="error">' . htmlspecialchars($error) . '</li>';
    }
    echo '</ul>';
}

echo '</div>';
?>

<div class="test-section">
    <h2>💡 Próximos Pasos</h2>
    <ol>
        <li><strong>Si todos los tests pasaron:</strong> El sistema está listo para usar</li>
        <li><strong>Probar invitación manual:</strong> Ve a /companies/ e intenta crear una invitación</li>
        <li><strong>Verificar emails:</strong> Asegúrate de que la configuración de email funcione</li>
        <li><strong>Test de registro:</strong> Usa un token de invitación para registrar un usuario nuevo</li>
    </ol>
</div>

</body>
</html>
