<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Debug Sistema Notificaciones</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .section { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        .error { color: #dc3545; background: #f8d7da; padding: 10px; border-radius: 5px; }
        .success { color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; }
        .warning { color: #856404; background: #fff3cd; padding: 10px; border-radius: 5px; }
        .info { color: #0c5460; background: #d1ecf1; padding: 10px; border-radius: 5px; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 8px; border: 1px solid #ddd; text-align: left; }
        th { background: #f8f9fa; }
    </style>
</head>
<body>

<h1>🔍 Debug Sistema de Notificaciones</h1>

<?php
require_once 'config.php';

try {
    $db = getDB();
    
    echo '<div class="section">';
    echo '<h2>1. 📋 Verificación de Tabla notifications</h2>';
    
    // Verificar si existe la tabla
    try {
        $stmt = $db->query("SHOW TABLES LIKE 'notifications'");
        $table_exists = $stmt->fetch();
        
        if ($table_exists) {
            echo '<div class="success">✅ La tabla notifications existe</div>';
            
            // Mostrar estructura
            $stmt = $db->query("DESCRIBE notifications");
            $columns = $stmt->fetchAll();
            
            echo '<h3>Estructura de la tabla:</h3>';
            echo '<table>';
            echo '<tr><th>Campo</th><th>Tipo</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>';
            foreach ($columns as $column) {
                echo '<tr>';
                echo '<td>' . $column['Field'] . '</td>';
                echo '<td>' . $column['Type'] . '</td>';
                echo '<td>' . $column['Null'] . '</td>';
                echo '<td>' . $column['Key'] . '</td>';
                echo '<td>' . $column['Default'] . '</td>';
                echo '<td>' . $column['Extra'] . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            
        } else {
            echo '<div class="error">❌ La tabla notifications NO existe</div>';
            echo '<div class="info">Vamos a crearla...</div>';
            
            // Crear la tabla
            $sql = "
            CREATE TABLE notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                user_id INT NOT NULL,
                type VARCHAR(50) NOT NULL,
                title VARCHAR(255) NOT NULL,
                message TEXT,
                data JSON,
                status ENUM('pending', 'unread', 'read', 'completed') DEFAULT 'unread',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_company_user (company_id, user_id),
                INDEX idx_status (status),
                INDEX idx_type (type),
                INDEX idx_created (created_at)
            )";
            
            $db->exec($sql);
            echo '<div class="success">✅ Tabla notifications creada exitosamente</div>';
        }
        
    } catch (Exception $e) {
        echo '<div class="error">❌ Error: ' . $e->getMessage() . '</div>';
    }
    
    echo '</div>';
    
    echo '<div class="section">';
    echo '<h2>2. 📊 Contenido Actual de notifications</h2>';
    
    try {
        $stmt = $db->query("SELECT COUNT(*) as total FROM notifications");
        $count = $stmt->fetchColumn();
        
        echo "<div class='info'>Total de registros: $count</div>";
        
        if ($count > 0) {
            $stmt = $db->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10");
            $notifications = $stmt->fetchAll();
            
            echo '<table>';
            echo '<tr><th>ID</th><th>Company ID</th><th>User ID</th><th>Type</th><th>Title</th><th>Status</th><th>Created</th></tr>';
            foreach ($notifications as $n) {
                echo '<tr>';
                echo '<td>' . $n['id'] . '</td>';
                echo '<td>' . $n['company_id'] . '</td>';
                echo '<td>' . $n['user_id'] . '</td>';
                echo '<td>' . $n['type'] . '</td>';
                echo '<td>' . htmlspecialchars($n['title']) . '</td>';
                echo '<td>' . $n['status'] . '</td>';
                echo '<td>' . $n['created_at'] . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        } else {
            echo '<div class="warning">⚠️ No hay notificaciones en la base de datos</div>';
        }
        
    } catch (Exception $e) {
        echo '<div class="error">❌ Error consultando notifications: ' . $e->getMessage() . '</div>';
    }
    
    echo '</div>';
    
    echo '<div class="section">';
    echo '<h2>3. 🔍 Verificación de user_invitations</h2>';
    
    try {
        $stmt = $db->query("SELECT COUNT(*) as total FROM user_invitations");
        $count = $stmt->fetchColumn();
        
        echo "<div class='info'>Total de invitaciones: $count</div>";
        
        if ($count > 0) {
            $stmt = $db->query("
                SELECT i.*, u.name as inviter_name, c.name as company_name
                FROM user_invitations i
                LEFT JOIN users u ON i.sent_by = u.id
                LEFT JOIN companies c ON i.company_id = c.id
                ORDER BY i.sent_date DESC 
                LIMIT 10
            ");
            $invitations = $stmt->fetchAll();
            
            echo '<table>';
            echo '<tr><th>ID</th><th>Email</th><th>Company</th><th>Sent By</th><th>Status</th><th>Sent Date</th></tr>';
            foreach ($invitations as $inv) {
                echo '<tr>';
                echo '<td>' . $inv['id'] . '</td>';
                echo '<td>' . htmlspecialchars($inv['email']) . '</td>';
                echo '<td>' . htmlspecialchars($inv['company_name']) . '</td>';
                echo '<td>' . htmlspecialchars($inv['inviter_name']) . '</td>';
                echo '<td>' . $inv['status'] . '</td>';
                echo '<td>' . $inv['sent_date'] . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        }
        
    } catch (Exception $e) {
        echo '<div class="error">❌ Error consultando user_invitations: ' . $e->getMessage() . '</div>';
    }
    
    echo '</div>';
    
    echo '<div class="section">';
    echo '<h2>4. 🧪 Test de Creación de Notificación</h2>';
    
    try {
        // Buscar un usuario y empresa para hacer prueba
        $stmt = $db->query("SELECT id, email FROM users LIMIT 1");
        $user = $stmt->fetch();
        
        $stmt = $db->query("SELECT id, name FROM companies LIMIT 1");
        $company = $stmt->fetch();
        
        if ($user && $company) {
            echo "<div class='info'>Probando con usuario: {$user['email']} y empresa: {$company['name']}</div>";
            
            // Incluir las funciones de notificaciones
            if (file_exists('includes/notifications.php')) {
                require_once 'includes/notifications.php';
                
                $notification_id = createInvitationNotification(
                    $company['id'], 
                    $user['id'], 
                    'test@example.com', 
                    2, 
                    'test'
                );
                
                if ($notification_id) {
                    echo '<div class="success">✅ Notificación de prueba creada con ID: ' . $notification_id . '</div>';
                    
                    // Verificar que se creó
                    $stmt = $db->prepare("SELECT * FROM notifications WHERE id = ?");
                    $stmt->execute([$notification_id]);
                    $created_notification = $stmt->fetch();
                    
                    if ($created_notification) {
                        echo '<pre>' . print_r($created_notification, true) . '</pre>';
                        
                        // Limpiar - eliminar la notificación de prueba
                        $stmt = $db->prepare("DELETE FROM notifications WHERE id = ?");
                        $stmt->execute([$notification_id]);
                        echo '<div class="info">Notificación de prueba eliminada</div>';
                    }
                } else {
                    echo '<div class="error">❌ Error creando notificación de prueba</div>';
                }
                
            } else {
                echo '<div class="error">❌ No se encuentra el archivo includes/notifications.php</div>';
            }
            
        } else {
            echo '<div class="warning">⚠️ No hay usuarios o empresas para hacer la prueba</div>';
        }
        
    } catch (Exception $e) {
        echo '<div class="error">❌ Error en test: ' . $e->getMessage() . '</div>';
    }
    
    echo '</div>';
    
    echo '<div class="section">';
    echo '<h2>5. 🔗 Verificación de Archivos Relacionados</h2>';
    
    $files_to_check = [
        'includes/notifications.php',
        'notifications/index.php',
        'companies/invite_user.php',
        'companies/create_invitation.php'
    ];
    
    foreach ($files_to_check as $file) {
        if (file_exists($file)) {
            echo "<div class='success'>✅ $file existe</div>";
        } else {
            echo "<div class='error'>❌ $file NO existe</div>";
        }
    }
    
    echo '</div>';
    
    echo '<div class="section">';
    echo '<h2>6. 💡 Diagnóstico y Recomendaciones</h2>';
    
    echo '<h3>Problemas Detectados:</h3>';
    echo '<ul>';
    
    // Verificar tabla existe y tiene datos
    $stmt = $db->query("SELECT COUNT(*) FROM notifications");
    $notification_count = $stmt->fetchColumn();
    
    if ($notification_count == 0) {
        echo '<li>⚠️ No hay notificaciones en la base de datos</li>';
        echo '<li>🔧 Solución: Crear una nueva invitación para generar notificaciones</li>';
    }
    
    echo '</ul>';
    
    echo '<h3>Próximos pasos:</h3>';
    echo '<ol>';
    echo '<li><a href="companies/invitations.php">Ir a gestión de invitaciones</a> y crear una nueva invitación</li>';
    echo '<li><a href="notifications/">Ver panel de notificaciones</a> para verificar que aparezcan</li>';
    echo '<li>Si sigue sin funcionar, revisar los logs de error del servidor</li>';
    echo '</ol>';
    
    echo '</div>';
    
} catch (Exception $e) {
    echo '<div class="error">❌ Error de conexión: ' . $e->getMessage() . '</div>';
}
?>

</body>
</html>
