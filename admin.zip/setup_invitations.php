<?php
require_once 'indice-produccion/conexion.php';

try {
    $db = getDB();
    
    echo "Creando tabla de invitaciones...\n";
    
    // Crear tabla de invitaciones
    $sql = "
    CREATE TABLE IF NOT EXISTS invitations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        inviter_user_id INT NOT NULL,
        email VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'user',
        token VARCHAR(255) NOT NULL UNIQUE,
        status ENUM('pending', 'accepted', 'expired', 'cancelled') DEFAULT 'pending',
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        accepted_at TIMESTAMP NULL,
        INDEX idx_token (token),
        INDEX idx_email (email),
        INDEX idx_status (status),
        INDEX idx_company (company_id),
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (inviter_user_id) REFERENCES users(id) ON DELETE CASCADE
    )";
    
    $db->exec($sql);
    echo "✅ Tabla de invitaciones creada exitosamente\n";
    
    // Agregar columna payment_status a companies si no existe
    echo "Verificando columna payment_status en companies...\n";
    $stmt = $db->query("SHOW COLUMNS FROM companies LIKE 'payment_status'");
    if (!$stmt->fetch()) {
        echo "Agregando columna payment_status...\n";
        $db->exec("ALTER TABLE companies ADD COLUMN payment_status ENUM('pending', 'active', 'suspended', 'cancelled') DEFAULT 'pending' AFTER plan_id");
        echo "✅ Columna payment_status agregada\n";
    } else {
        echo "✅ Columna payment_status ya existe\n";
    }
    
    // Agregar columna subscription_expires_at si no existe
    echo "Verificando columna subscription_expires_at en companies...\n";
    $stmt = $db->query("SHOW COLUMNS FROM companies LIKE 'subscription_expires_at'");
    if (!$stmt->fetch()) {
        echo "Agregando columna subscription_expires_at...\n";
        $db->exec("ALTER TABLE companies ADD COLUMN subscription_expires_at TIMESTAMP NULL AFTER payment_status");
        echo "✅ Columna subscription_expires_at agregada\n";
    } else {
        echo "✅ Columna subscription_expires_at ya existe\n";
    }
    
    echo "\n=== Configuración completada ===\n";
    echo "Funcionalidades habilitadas:\n";
    echo "- ✅ Sistema de invitaciones\n";
    echo "- ✅ Control de estados de pago\n";
    echo "- ✅ Fechas de vencimiento de suscripciones\n";
    echo "- ✅ Registro por tipo de cuenta\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
