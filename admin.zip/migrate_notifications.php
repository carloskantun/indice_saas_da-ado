<?php
require_once 'config.php';

echo "🔧 **MIGRACIÓN SISTEMA DE NOTIFICACIONES**\n";
echo "==========================================\n\n";

try {
    $db = getDB();
    
    echo "1. 📊 **Análisis de notificaciones actuales**\n";
    echo "----------------------------------------------\n";
    
    // Analizar notificaciones existentes
    $stmt = $db->query("
        SELECT 
            n.*,
            JSON_EXTRACT(n.data, '$.email') as invitation_email,
            u.email as notification_user_email,
            c.name as company_name
        FROM notifications n
        LEFT JOIN users u ON n.user_id = u.id
        LEFT JOIN companies c ON n.company_id = c.id
        WHERE n.type = 'invitation'
        ORDER BY n.created_at DESC
    ");
    $notifications = $stmt->fetchAll();
    
    echo "   📈 Total de notificaciones de invitación: " . count($notifications) . "\n";
    
    $incorrect_notifications = [];
    $correct_notifications = [];
    
    foreach ($notifications as $notification) {
        $data = json_decode($notification['data'], true);
        $invitation_email = $data['email'] ?? null;
        $notification_user_email = $notification['notification_user_email'];
        
        // Verificar si la notificación está mal asignada
        if ($invitation_email && $notification_user_email && $invitation_email !== $notification_user_email) {
            $incorrect_notifications[] = $notification;
        } else {
            $correct_notifications[] = $notification;
        }
    }
    
    echo "   ❌ Notificaciones incorrectas: " . count($incorrect_notifications) . "\n";
    echo "   ✅ Notificaciones correctas: " . count($correct_notifications) . "\n\n";
    
    if (count($incorrect_notifications) > 0) {
        echo "2. 🔄 **Corrección de notificaciones**\n";
        echo "------------------------------------\n";
        
        $fixed_count = 0;
        $deleted_count = 0;
        
        foreach ($incorrect_notifications as $notification) {
            $data = json_decode($notification['data'], true);
            $invitation_email = $data['email'];
            
            echo "   📧 Procesando invitación para: $invitation_email\n";
            
            // Buscar si el usuario invitado existe
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$invitation_email]);
            $invited_user = $stmt->fetch();
            
            if ($invited_user) {
                // Usuario existe - reasignar notificación al usuario correcto
                $stmt = $db->prepare("
                    UPDATE notifications 
                    SET 
                        user_id = ?,
                        title = 'Nueva invitación recibida',
                        message = ?,
                        data = ?,
                        updated_at = NOW()
                    WHERE id = ?
                ");
                
                $new_message = sprintf(
                    'Has sido invitado a unirte a %s con nivel %d. Puedes aceptar la invitación desde aquí.',
                    $notification['company_name'],
                    $data['nivel']
                );
                
                $data['can_accept'] = true;
                $data['user_exists'] = true;
                $data['invited_user_id'] = $invited_user['id'];
                
                $stmt->execute([
                    $invited_user['id'],
                    $new_message,
                    json_encode($data),
                    $notification['id']
                ]);
                
                echo "      ✅ Reasignada al usuario correcto\n";
                $fixed_count++;
                
            } else {
                // Usuario no existe - eliminar notificación o convertir en informativa
                echo "      ⚠️  Usuario no existe - eliminando notificación\n";
                
                $stmt = $db->prepare("DELETE FROM notifications WHERE id = ?");
                $stmt->execute([$notification['id']]);
                
                $deleted_count++;
            }
        }
        
        echo "\n   📊 Resultado:\n";
        echo "      - Notificaciones corregidas: $fixed_count\n";
        echo "      - Notificaciones eliminadas: $deleted_count\n\n";
    }
    
    echo "3. ✅ **Verificación final**\n";
    echo "----------------------------\n";
    
    // Verificar el estado final
    $stmt = $db->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN n.status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN n.status = 'completed' THEN 1 ELSE 0 END) as completed
        FROM notifications n
        WHERE n.type = 'invitation'
    ");
    $stats = $stmt->fetch();
    
    echo "   📈 Estadísticas finales:\n";
    echo "      - Total: {$stats['total']}\n";
    echo "      - Pendientes: {$stats['pending']}\n";
    echo "      - Completadas: {$stats['completed']}\n\n";
    
    // Mostrar ejemplos de notificaciones corregidas
    $stmt = $db->query("
        SELECT 
            n.*,
            u.email as user_email,
            c.name as company_name,
            JSON_EXTRACT(n.data, '$.email') as invitation_email
        FROM notifications n
        LEFT JOIN users u ON n.user_id = u.id
        LEFT JOIN companies c ON n.company_id = c.id
        WHERE n.type = 'invitation'
        ORDER BY n.updated_at DESC
        LIMIT 5
    ");
    $examples = $stmt->fetchAll();
    
    echo "4. 📋 **Ejemplos de notificaciones actuales**\n";
    echo "---------------------------------------------\n";
    
    foreach ($examples as $example) {
        $data = json_decode($example['data'], true);
        $match = ($example['user_email'] === $data['email']) ? '✅' : '❌';
        
        echo "   $match ID: {$example['id']}\n";
        echo "      - Empresa: {$example['company_name']}\n";
        echo "      - Notificación para: {$example['user_email']}\n";
        echo "      - Invitación para: {$data['email']}\n";
        echo "      - Estado: {$example['status']}\n";
        echo "      - Puede aceptar: " . ($data['can_accept'] ? 'Sí' : 'No') . "\n\n";
    }
    
    echo "🎉 **MIGRACIÓN COMPLETADA**\n";
    echo "==========================\n";
    echo "✅ El sistema de notificaciones ha sido corregido\n";
    echo "✅ Las invitaciones ahora llegan a los usuarios correctos\n";
    echo "✅ Solo usuarios existentes pueden aceptar invitaciones directamente\n\n";
    
    echo "💡 **Próximos pasos:**\n";
    echo "1. Probar crear una nueva invitación\n";
    echo "2. Verificar que llegue al usuario correcto\n";
    echo "3. Probar aceptar una invitación\n";
    
} catch (Exception $e) {
    echo "❌ Error durante la migración: " . $e->getMessage() . "\n";
}
?>
