<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración SaaS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Configuración del Sistema SaaS</h1>
        
        <?php
        if (isset($_GET['run_setup'])) {
            echo '<div class="card">';
            echo '<div class="card-body">';
            echo '<pre>';
            
            require_once 'indice-produccion/conexion.php';
            require_once 'includes/notifications.php';

            try {
                $db = getDB();
                
                echo "Inicializando base de datos para SaaS completo...\n";
                
                // 1. Crear tabla de notificaciones
                echo "Creando tabla de notificaciones...\n";
                createNotificationsTable();
                
                // 2. Verificar y actualizar tabla de empresas para incluir plan_id
                echo "Verificando estructura de tabla companies...\n";
                $stmt = $db->query("SHOW COLUMNS FROM companies LIKE 'plan_id'");
                if (!$stmt->fetch()) {
                    echo "Agregando columna plan_id a tabla companies...\n";
                    $db->exec("ALTER TABLE companies ADD COLUMN plan_id INT DEFAULT 1 AFTER id");
                    $db->exec("ALTER TABLE companies ADD FOREIGN KEY (plan_id) REFERENCES plans(id)");
                }
                
                // 3. Verificar que existe la tabla de planes con datos
                echo "Verificando tabla de planes...\n";
                $stmt = $db->query("SELECT COUNT(*) FROM plans WHERE status = 'active'");
                $plan_count = $stmt->fetchColumn();
                
                if ($plan_count == 0) {
                    echo "Insertando planes por defecto...\n";
                    $db->exec("
                        INSERT INTO plans (name, description, price, users_max, businesses_max, units_max, storage_max_mb, features, status) VALUES
                        ('Gratuito', 'Plan básico gratuito con funcionalidades limitadas', 0.00, 5, 2, 10, 100, '[\"basic_modules\"]', 'active'),
                        ('Premium', 'Plan premium con todas las funcionalidades', 29.99, -1, -1, -1, 1000, '[\"basic_modules\", \"premium_modules\", \"advanced_reports\", \"export_data\"]', 'active'),
                        ('Enterprise', 'Plan empresarial para organizaciones grandes', 99.99, -1, -1, -1, -1, '[\"basic_modules\", \"premium_modules\", \"advanced_reports\", \"export_data\", \"custom_branding\", \"priority_support\"]', 'active')
                    ");
                }
                
                // 4. Actualizar empresas existentes para tener un plan asignado
                echo "Asignando plan gratuito a empresas sin plan...\n";
                $db->exec("UPDATE companies SET plan_id = 1 WHERE plan_id IS NULL OR plan_id = 0");
                
                // 5. Verificar estructura de user_companies para nivel
                echo "Verificando estructura de tabla user_companies...\n";
                $stmt = $db->query("SHOW COLUMNS FROM user_companies LIKE 'nivel'");
                if (!$stmt->fetch()) {
                    echo "Agregando columna nivel a tabla user_companies...\n";
                    $db->exec("ALTER TABLE user_companies ADD COLUMN nivel INT DEFAULT 1 AFTER role");
                    // Convertir roles existentes a niveles
                    $db->exec("UPDATE user_companies SET nivel = 3 WHERE role IN ('admin', 'superadmin', 'root')");
                    $db->exec("UPDATE user_companies SET nivel = 2 WHERE role = 'moderator'");
                    $db->exec("UPDATE user_companies SET nivel = 1 WHERE role = 'user' OR nivel = 0");
                }
                
                echo "\n=== RESUMEN DE INICIALIZACIÓN ===\n";
                
                // Mostrar estadísticas
                $stmt = $db->query("SELECT COUNT(*) FROM plans WHERE status = 'active'");
                echo "Planes activos: " . $stmt->fetchColumn() . "\n";
                
                $stmt = $db->query("SELECT COUNT(*) FROM companies");
                echo "Empresas registradas: " . $stmt->fetchColumn() . "\n";
                
                $stmt = $db->query("SELECT COUNT(*) FROM users");
                echo "Usuarios registrados: " . $stmt->fetchColumn() . "\n";
                
                $stmt = $db->query("SELECT COUNT(*) FROM notifications");
                echo "Notificaciones en sistema: " . $stmt->fetchColumn() . "\n";
                
                echo "\n✅ Inicialización completada exitosamente!\n";
                echo "\nFuncionalidades disponibles:\n";
                echo "- ✅ Registro con selección de planes\n";
                echo "- ✅ Sistema de invitaciones con fallback a notificaciones\n";
                echo "- ✅ Restricciones basadas en planes\n";
                echo "- ✅ Panel de notificaciones interno\n";
                echo "- ✅ Widgets de uso de plan\n";
                echo "- ✅ Aceptación de invitaciones desde el sistema\n";
                
            } catch (Exception $e) {
                echo "❌ Error durante la inicialización: " . $e->getMessage() . "\n";
                echo "Trace: " . $e->getTraceAsString() . "\n";
            }
            
            echo '</pre>';
            echo '</div>';
            echo '</div>';
            
            echo '<div class="mt-3">';
            echo '<a href="auth/register.php" class="btn btn-primary me-2">Ir a Registro</a>';
            echo '<a href="companies/" class="btn btn-secondary me-2">Ir a Empresas</a>';
            echo '<a href="notifications/" class="btn btn-info">Ir a Notificaciones</a>';
            echo '</div>';
        } else {
            ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">¿Deseas ejecutar la configuración del sistema SaaS?</h5>
                    <p class="card-text">
                        Esto creará las tablas necesarias e inicializará los datos para:
                    </p>
                    <ul>
                        <li>Sistema de planes (Gratuito, Premium, Enterprise)</li>
                        <li>Notificaciones internas</li>
                        <li>Restricciones basadas en planes</li>
                        <li>Sistema de invitaciones</li>
                    </ul>
                    <a href="?run_setup=1" class="btn btn-success">Ejecutar Configuración</a>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</body>
</html>
