<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Migración Sistema de Notificaciones</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; background: #f8f9fa; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        .info { color: #17a2b8; }
        .section { margin-bottom: 30px; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .stat-card { text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef; }
        .stat-number { font-size: 24px; font-weight: bold; margin: 5px 0; }
        .notification-item { margin: 10px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #007bff; }
        .notification-item.incorrect { border-left-color: #dc3545; }
        .notification-item.correct { border-left-color: #28a745; }
        .btn { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; margin: 10px 10px 10px 0; }
        .btn:hover { background: #0056b3; }
        .btn-success { background: #28a745; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>

<div class="container">
    <h1>🔧 Migración Sistema de Notificaciones</h1>
    <p class="info">Este script corrige el problema donde las notificaciones de invitación llegaban a los usuarios incorrectos.</p>

    <?php
    require_once 'config.php';

    try {
        $db = getDB();
        
        echo '<div class="section">';
        echo '<h2>📊 Análisis de Notificaciones Actuales</h2>';
        
        // Analizar notificaciones existentes
        $stmt = $db->query("
            SELECT 
                n.*,
                JSON_EXTRACT(n.data, '$.email') as invitation_email,
                u.email as notification_user_email,
                c.name as company_name
            FROM notifications n
            LEFT JOIN users u ON n.user_id = u.id
            LEFT JOIN companies c ON n.company_id = c.id
            WHERE n.type = 'invitation'
            ORDER BY n.created_at DESC
        ");
        $notifications = $stmt->fetchAll();
        
        $incorrect_notifications = [];
        $correct_notifications = [];
        
        foreach ($notifications as $notification) {
            $data = json_decode($notification['data'], true);
            $invitation_email = $data['email'] ?? null;
            $notification_user_email = $notification['notification_user_email'];
            
            // Verificar si la notificación está mal asignada
            if ($invitation_email && $notification_user_email && $invitation_email !== $notification_user_email) {
                $incorrect_notifications[] = $notification;
            } else {
                $correct_notifications[] = $notification;
            }
        }
        
        echo '<div class="stat-grid">';
        echo '<div class="stat-card">';
        echo '<div class="stat-number info">' . count($notifications) . '</div>';
        echo '<div>Total Notificaciones</div>';
        echo '</div>';
        
        echo '<div class="stat-card">';
        echo '<div class="stat-number error">' . count($incorrect_notifications) . '</div>';
        echo '<div>Incorrectas</div>';
        echo '</div>';
        
        echo '<div class="stat-card">';
        echo '<div class="stat-number success">' . count($correct_notifications) . '</div>';
        echo '<div>Correctas</div>';
        echo '</div>';
        echo '</div>';
        
        if (count($incorrect_notifications) > 0) {
            echo '<div class="warning" style="padding: 15px; background: #fff3cd; border-radius: 8px; margin: 20px 0;">';
            echo '<strong>⚠️ Problema detectado:</strong> ' . count($incorrect_notifications) . ' notificaciones están asignadas incorrectamente.';
            echo '</div>';
        } else {
            echo '<div class="success" style="padding: 15px; background: #d4edda; border-radius: 8px; margin: 20px 0;">';
            echo '<strong>✅ Todo correcto:</strong> No se encontraron notificaciones mal asignadas.';
            echo '</div>';
        }
        
        echo '</div>';
        
        // Mostrar ejemplos de notificaciones problemáticas
        if (count($incorrect_notifications) > 0) {
            echo '<div class="section">';
            echo '<h2>❌ Notificaciones Problemáticas</h2>';
            echo '<p>Estas notificaciones están llegando al usuario equivocado:</p>';
            
            foreach (array_slice($incorrect_notifications, 0, 5) as $notification) {
                $data = json_decode($notification['data'], true);
                echo '<div class="notification-item incorrect">';
                echo '<strong>ID:</strong> ' . $notification['id'] . '<br>';
                echo '<strong>Empresa:</strong> ' . htmlspecialchars($notification['company_name']) . '<br>';
                echo '<strong>Notificación asignada a:</strong> ' . htmlspecialchars($notification['notification_user_email']) . '<br>';
                echo '<strong>Invitación para:</strong> ' . htmlspecialchars($data['email']) . '<br>';
                echo '<strong>Estado:</strong> ' . $notification['status'];
                echo '</div>';
            }
            
            if (count($incorrect_notifications) > 5) {
                echo '<p class="info">... y ' . (count($incorrect_notifications) - 5) . ' más.</p>';
            }
            echo '</div>';
        }
        
        // Procesar corrección si se solicita
        if (isset($_POST['fix_notifications']) && count($incorrect_notifications) > 0) {
            echo '<div class="section">';
            echo '<h2>🔄 Procesando Correcciones</h2>';
            
            $fixed_count = 0;
            $deleted_count = 0;
            
            foreach ($incorrect_notifications as $notification) {
                $data = json_decode($notification['data'], true);
                $invitation_email = $data['email'];
                
                echo '<div class="notification-item">';
                echo '<strong>📧 Procesando:</strong> ' . htmlspecialchars($invitation_email) . '<br>';
                
                // Buscar si el usuario invitado existe
                $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$invitation_email]);
                $invited_user = $stmt->fetch();
                
                if ($invited_user) {
                    // Usuario existe - reasignar notificación al usuario correcto
                    $stmt = $db->prepare("
                        UPDATE notifications 
                        SET 
                            user_id = ?,
                            title = 'Nueva invitación recibida',
                            message = ?,
                            data = ?,
                            updated_at = NOW()
                        WHERE id = ?
                    ");
                    
                    $new_message = sprintf(
                        'Has sido invitado a unirte a %s con nivel %d. Puedes aceptar la invitación desde aquí.',
                        $notification['company_name'],
                        $data['nivel']
                    );
                    
                    $data['can_accept'] = true;
                    $data['user_exists'] = true;
                    $data['invited_user_id'] = $invited_user['id'];
                    
                    $stmt->execute([
                        $invited_user['id'],
                        $new_message,
                        json_encode($data),
                        $notification['id']
                    ]);
                    
                    echo '<span class="success">✅ Reasignada al usuario correcto</span>';
                    $fixed_count++;
                    
                } else {
                    // Usuario no existe - eliminar notificación
                    $stmt = $db->prepare("DELETE FROM notifications WHERE id = ?");
                    $stmt->execute([$notification['id']]);
                    
                    echo '<span class="warning">⚠️ Usuario no existe - notificación eliminada</span>';
                    $deleted_count++;
                }
                
                echo '</div>';
            }
            
            echo '<div class="success" style="padding: 20px; background: #d4edda; border-radius: 8px; margin: 20px 0;">';
            echo '<h3>✅ Corrección Completada</h3>';
            echo '<ul>';
            echo '<li><strong>Notificaciones corregidas:</strong> ' . $fixed_count . '</li>';
            echo '<li><strong>Notificaciones eliminadas:</strong> ' . $deleted_count . '</li>';
            echo '</ul>';
            echo '</div>';
        }
        
        // Estadísticas finales
        echo '<div class="section">';
        echo '<h2>📊 Estado Actual del Sistema</h2>';
        
        $stmt = $db->query("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN n.status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN n.status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN n.status = 'unread' THEN 1 ELSE 0 END) as unread
            FROM notifications n
            WHERE n.type = 'invitation'
        ");
        $stats = $stmt->fetch();
        
        echo '<div class="stat-grid">';
        echo '<div class="stat-card">';
        echo '<div class="stat-number">' . $stats['total'] . '</div>';
        echo '<div>Total</div>';
        echo '</div>';
        
        echo '<div class="stat-card">';
        echo '<div class="stat-number warning">' . $stats['pending'] . '</div>';
        echo '<div>Pendientes</div>';
        echo '</div>';
        
        echo '<div class="stat-card">';
        echo '<div class="stat-number success">' . $stats['completed'] . '</div>';
        echo '<div>Completadas</div>';
        echo '</div>';
        
        echo '<div class="stat-card">';
        echo '<div class="stat-number info">' . $stats['unread'] . '</div>';
        echo '<div>No leídas</div>';
        echo '</div>';
        echo '</div>';
        
        echo '</div>';
        
        // Mostrar ejemplos actuales
        echo '<div class="section">';
        echo '<h2>📋 Ejemplos de Notificaciones Actuales</h2>';
        
        $stmt = $db->query("
            SELECT 
                n.*,
                u.email as user_email,
                c.name as company_name,
                JSON_EXTRACT(n.data, '$.email') as invitation_email
            FROM notifications n
            LEFT JOIN users u ON n.user_id = u.id
            LEFT JOIN companies c ON n.company_id = c.id
            WHERE n.type = 'invitation'
            ORDER BY n.updated_at DESC
            LIMIT 5
        ");
        $examples = $stmt->fetchAll();
        
        foreach ($examples as $example) {
            $data = json_decode($example['data'], true);
            $is_correct = ($example['user_email'] === $data['email']);
            $class = $is_correct ? 'correct' : 'incorrect';
            
            echo '<div class="notification-item ' . $class . '">';
            echo '<div style="display: flex; justify-content: between; align-items: start;">';
            echo '<div style="flex: 1;">';
            echo '<strong>ID:</strong> ' . $example['id'] . ' ' . ($is_correct ? '✅' : '❌') . '<br>';
            echo '<strong>Empresa:</strong> ' . htmlspecialchars($example['company_name']) . '<br>';
            echo '<strong>Notificación para:</strong> ' . htmlspecialchars($example['user_email']) . '<br>';
            echo '<strong>Invitación para:</strong> ' . htmlspecialchars($data['email']) . '<br>';
            echo '<strong>Estado:</strong> ' . $example['status'] . '<br>';
            echo '<strong>Puede aceptar:</strong> ' . ($data['can_accept'] ? 'Sí' : 'No');
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        
        echo '</div>';
        
        // Acciones disponibles
        echo '<div class="section">';
        echo '<h2>🎯 Acciones Disponibles</h2>';
        
        if (count($incorrect_notifications) > 0) {
            echo '<form method="post" style="margin: 20px 0;">';
            echo '<button type="submit" name="fix_notifications" class="btn btn-warning" onclick="return confirm(\'¿Estás seguro de que quieres corregir las notificaciones incorrectas?\')">🔧 Corregir Notificaciones Incorrectas</button>';
            echo '</form>';
        }
        
        echo '<a href="notifications/" class="btn btn-success">📧 Ver Panel de Notificaciones</a>';
        echo '<a href="companies/invitations.php" class="btn">👥 Gestionar Invitaciones</a>';
        echo '<a href="test_invitations_web.php" class="btn">🧪 Test Sistema Completo</a>';
        echo '</div>';
        
    } catch (Exception $e) {
        echo '<div class="section">';
        echo '<div class="error" style="padding: 20px; background: #f8d7da; border-radius: 8px;">';
        echo '<h3>❌ Error</h3>';
        echo '<p>Error durante el análisis: ' . htmlspecialchars($e->getMessage()) . '</p>';
        echo '</div>';
        echo '</div>';
    }
    ?>

    <div class="section">
        <h2>💡 Información del Sistema</h2>
        <p><strong>Problema resuelto:</strong> Las notificaciones de invitación ahora se asignan correctamente:</p>
        <ul>
            <li>✅ <strong>Usuarios existentes:</strong> Reciben la notificación directamente y pueden aceptar</li>
            <li>✅ <strong>Usuarios nuevos:</strong> Se maneja a través del sistema de invitaciones tradicional</li>
            <li>✅ <strong>Sin duplicados:</strong> Se previenen invitaciones a miembros existentes</li>
            <li>✅ <strong>Feedback claro:</strong> Mensajes apropiados según el contexto</li>
        </ul>
    </div>

</div>

</body>
</html>
