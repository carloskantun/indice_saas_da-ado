<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Sistema de Invitaciones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Sistema de Invitaciones - Configuración</h1>
        
        <?php
        if (isset($_GET['run_setup'])) {
            echo '<div class="card">';
            echo '<div class="card-body">';
            echo '<pre>';
            
            require_once 'config.php';

            try {
                $db = getDB();
                
                echo "Configurando sistema de invitaciones...\n";
                
                // Crear tabla de invitaciones
                $sql = "
                CREATE TABLE IF NOT EXISTS invitations (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    inviter_user_id INT NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    role VARCHAR(50) NOT NULL DEFAULT 'user',
                    token VARCHAR(255) NOT NULL UNIQUE,
                    status ENUM('pending', 'accepted', 'expired', 'cancelled') DEFAULT 'pending',
                    expires_at TIMESTAMP NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    accepted_at TIMESTAMP NULL,
                    INDEX idx_token (token),
                    INDEX idx_email (email),
                    INDEX idx_status (status),
                    INDEX idx_company (company_id),
                    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
                    FOREIGN KEY (inviter_user_id) REFERENCES users(id) ON DELETE CASCADE
                )";
                
                $db->exec($sql);
                echo "✅ Tabla de invitaciones creada\n";
                
                // Agregar columna payment_status a companies si no existe
                $stmt = $db->query("SHOW COLUMNS FROM companies LIKE 'payment_status'");
                if (!$stmt->fetch()) {
                    $db->exec("ALTER TABLE companies ADD COLUMN payment_status ENUM('pending', 'active', 'suspended', 'cancelled') DEFAULT 'pending' AFTER plan_id");
                    echo "✅ Columna payment_status agregada\n";
                } else {
                    echo "✅ Columna payment_status ya existe\n";
                }
                
                // Agregar columna subscription_expires_at si no existe
                $stmt = $db->query("SHOW COLUMNS FROM companies LIKE 'subscription_expires_at'");
                if (!$stmt->fetch()) {
                    $db->exec("ALTER TABLE companies ADD COLUMN subscription_expires_at TIMESTAMP NULL AFTER payment_status");
                    echo "✅ Columna subscription_expires_at agregada\n";
                } else {
                    echo "✅ Columna subscription_expires_at ya existe\n";
                }
                
                // Actualizar empresas existentes para tener payment_status active
                $db->exec("UPDATE companies SET payment_status = 'active' WHERE payment_status IS NULL");
                echo "✅ Estados de pago actualizados\n";
                
                echo "\n=== SISTEMA CONFIGURADO ===\n";
                echo "Funcionalidades disponibles:\n";
                echo "- ✅ Registro por tipo de cuenta (Superadmin/Gratuito)\n";
                echo "- ✅ Sistema de invitaciones con tokens\n";
                echo "- ✅ Control de estados de pago\n";
                echo "- ✅ Gestión de invitaciones\n";
                echo "- ✅ Panel root para gestionar planes\n";
                
                echo "\n=== PRÓXIMOS PASOS ===\n";
                echo "1. Crear cuenta superadmin: auth/register.php\n";
                echo "2. Gestionar invitaciones: companies/invitations.php\n";
                echo "3. Panel root: panel_root/\n";
                echo "4. Configurar pagos (siguiente fase)\n";
                
            } catch (Exception $e) {
                echo "❌ Error: " . $e->getMessage() . "\n";
            }
            
            echo '</pre>';
            echo '</div>';
            echo '</div>';
            
            echo '<div class="mt-3">';
            echo '<a href="auth/register.php" class="btn btn-primary me-2">Probar Registro</a>';
            echo '<a href="companies/" class="btn btn-secondary me-2">Ir a Empresas</a>';
            echo '<a href="panel_root/" class="btn btn-warning">Panel Root</a>';
            echo '</div>';
        } else {
            ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Configurar Sistema de Invitaciones</h5>
                    <p class="card-text">
                        Esto configurará el sistema para permitir:
                    </p>
                    <ul>
                        <li><strong>Registro por tipos:</strong> Cuentas Superadmin (con pago) y Gratuitas (por invitación)</li>
                        <li><strong>Sistema de invitaciones:</strong> Tokens únicos con expiración</li>
                        <li><strong>Control de pagos:</strong> Estados de suscripción por empresa</li>
                        <li><strong>Gestión de usuarios:</strong> Roles y permisos</li>
                    </ul>
                    <a href="?run_setup=1" class="btn btn-success">Configurar Sistema</a>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    <h5>🎯 Flujo de Negocio</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>📝 Cuenta Superadmin</h6>
                            <ol>
                                <li>Se registra seleccionando plan de pago</li>
                                <li>Se crea empresa automáticamente</li>
                                <li>Puede invitar usuarios</li>
                                <li>Acceso completo a módulos</li>
                            </ol>
                        </div>
                        <div class="col-md-6">
                            <h6>👥 Cuenta Gratuita</h6>
                            <ol>
                                <li>Requiere invitación con token</li>
                                <li>Se une a empresa existente</li>
                                <li>Acceso según rol asignado</li>
                                <li>Limitado por plan de la empresa</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</body>
</html>
