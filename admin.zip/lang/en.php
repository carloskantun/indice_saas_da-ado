<?php
/**
 * English language file
 * Indice SaaS - Modular System
 */

return [
    // General
    'app_name' => 'Indice SaaS',
    'welcome' => 'Welcome',
    'dashboard' => 'Dashboard',
    'logout' => 'Logout',
    'login' => 'Login',
    'register' => 'Register',
    'email' => 'Email',
    'password' => 'Password',
    'name' => 'Name',
    'actions' => 'Actions',
    'create' => 'Create',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'view' => 'View',
    'save' => 'Save',
    'cancel' => 'Cancel',
    'confirm' => 'Confirm',
    'yes' => 'Yes',
    'no' => 'No',
    'search' => 'Search',
    'date' => 'Date',
    'status' => 'Status',
    'active' => 'Active',
    'inactive' => 'Inactive',
    
    // Companies
    'companies' => 'Companies',
    'company' => 'Company',
    'new_company' => 'New Company',
    'company_name' => 'Company Name',
    'company_description' => 'Description',
    'no_companies' => 'No companies created yet',
    'create_first_company' => 'Create your first company to get started',
    'companies_list' => 'Companies List',
    'create_company' => 'Create Company',
    'join_company' => 'Join with Code',
    
    // Units
    'units' => 'Units',
    'unit' => 'Unit',
    'new_unit' => 'New Unit',
    'unit_name' => 'Unit Name',
    'unit_description' => 'Unit Description',
    'no_units' => 'No units created yet',
    'create_first_unit' => 'Create your first unit',
    'units_list' => 'Units List',
    'select_company_first' => 'Select a company first',
    
    // Businesses
    'businesses' => 'Businesses',
    'business' => 'Business',
    'new_business' => 'New Business',
    'business_name' => 'Business Name',
    'business_description' => 'Business Description',
    'business_type' => 'Business Type',
    'no_businesses' => 'No businesses created yet',
    'create_first_business' => 'Create your first business',
    'businesses_list' => 'Businesses List',
    'select_unit_first' => 'Select a unit first',
    
    // Auth messages
    'invalid_email' => 'Invalid email address',
    'password_too_short' => 'Password must be at least 6 characters',
    'passwords_dont_match' => 'Passwords do not match',
    'login_title' => 'Login',
    'register_title' => 'Create Account',
    'login_failed' => 'Invalid credentials',
    'account_inactive' => 'Account is inactive',
    
    // Registration & Auth Messages
    'complete_required_fields' => 'Please fill in all required fields',
    'email_already_registered' => 'This email address is already registered',
    'invalid_invitation_token' => 'Invalid or expired invitation token',
    'free_account_needs_invitation' => 'Free accounts require an invitation. Contact an administrator',
    'superadmin_needs_paid_plan' => 'Superadmin accounts require a paid plan',
    'free_account_created_success' => 'Free account created successfully. You have been assigned to the company',
    'invalid_plan_selected' => 'Invalid plan selected',
    'superadmin_account_created' => 'Superadmin account created successfully. You can now proceed to payment and login',
    'system_error' => 'System error. Please try again later',
    
    // Plans
    'plans' => 'Plans',
    'plan' => 'Plan',
    'select_plan' => 'Select Plan',
    'current_plan' => 'Current Plan',
    'upgrade_plan' => 'Upgrade Plan',
    'plan_features' => 'Plan Features',
    'monthly' => 'Monthly',
    'annually' => 'Annually',
    'free_plan' => 'Free Plan',
    'starter_plan' => 'Starter Plan',
    'pro_plan' => 'Pro Plan',
    'enterprise_plan' => 'Enterprise Plan',
    
    // Messages
    'success' => 'Success',
    'error' => 'Error',
    'warning' => 'Warning',
    'info' => 'Information',
    'created_successfully' => 'Created successfully',
    'updated_successfully' => 'Updated successfully',
    'deleted_successfully' => 'Deleted successfully',
    'operation_completed' => 'Operation completed',
    'operation_failed' => 'Operation failed',
    'unauthorized' => 'Unauthorized access',
    'not_found' => 'Not found',
    'server_error' => 'Server error',
    
    // Navigation
    'home' => 'Home',
    'profile' => 'Profile',
    'settings' => 'Settings',
    'help' => 'Help',
    'about' => 'About',
    'contact' => 'Contact',
    'back' => 'Back',
    'next' => 'Next',
    'previous' => 'Previous',
    'close' => 'Close',
    
    // Forms
    'submit' => 'Submit',
    'reset' => 'Reset',
    'clear' => 'Clear',
    'upload' => 'Upload',
    'download' => 'Download',
    'import' => 'Import',
    'export' => 'Export',
    'print' => 'Print',
    'required_field' => 'Required field',
    'optional_field' => 'Optional field',
    
    // Invitations
    'invitations' => 'Invitations',
    'invite_user' => 'Invite User',
    'invitation_sent' => 'Invitation sent',
    'invitation_accepted' => 'Invitation accepted',
    'invitation_expired' => 'Invitation expired',
    'invitation_pending' => 'Invitation pending',
    'send_invitation' => 'Send Invitation',
    'invitation_link' => 'Invitation Link',
    'copy_link' => 'Copy Link',
    
    // Roles
    'role' => 'Role',
    'roles' => 'Roles',
    'superadmin' => 'Super Administrator',
    'admin' => 'Administrator',
    'moderator' => 'Moderator',
    'user' => 'User',
    'support' => 'Support',
    'root' => 'Root',
    
    // Permissions
    'permissions' => 'Permissions',
    'permission' => 'Permission',
    'can_view' => 'Can View',
    'can_create' => 'Can Create',
    'can_edit' => 'Can Edit',
    'can_delete' => 'Can Delete',
    'can_admin' => 'Can Administer',
    'grant_permission' => 'Grant Permission',
    'revoke_permission' => 'Revoke Permission',
    
    // Modules
    'modules' => 'Modules',
    'module' => 'Module',
    'expenses' => 'Expenses',
    'maintenance' => 'Maintenance',
    'customer_service' => 'Customer Service',
    'transfers' => 'Transfers',
    'reports' => 'Reports',
    'orders' => 'Orders',
    'users' => 'Users',
    
    // File operations
    'file_uploaded' => 'File uploaded successfully',
    'file_upload_failed' => 'File upload failed',
    'file_too_large' => 'File is too large',
    'invalid_file_type' => 'Invalid file type',
    'file_not_found' => 'File not found',
    
    // Time & dates
    'today' => 'Today',
    'yesterday' => 'Yesterday',
    'tomorrow' => 'Tomorrow',
    'this_week' => 'This Week',
    'this_month' => 'This Month',
    'this_year' => 'This Year',
    'last_week' => 'Last Week',
    'last_month' => 'Last Month',
    'last_year' => 'Last Year',
    
    // Notifications
    'notifications' => 'Notifications',
    'notification' => 'Notification',
    'mark_as_read' => 'Mark as Read',
    'mark_all_read' => 'Mark All as Read',
    'no_notifications' => 'No notifications',
    'new_notification' => 'New Notification',
];
?>
