<?php
// Test script to verify all fixes
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "🔧 Testing Production Fixes\n";
echo "============================\n\n";

// Test 1: Email config
echo "1. Testing admin/email_config.php...\n";
try {
    include_once 'admin/email_config.php';
    echo "   ✅ Email config loads successfully\n";
} catch (Exception $e) {
    echo "   ❌ Error: " . $e->getMessage() . "\n";
}

// Test 2: Config file
echo "\n2. Testing config.php...\n";
try {
    include_once 'config.php';
    echo "   ✅ Config loads successfully\n";
    echo "   ✅ Database connection available: " . (isset($conexion) ? 'Yes' : 'No') . "\n";
} catch (Exception $e) {
    echo "   ❌ Error: " . $e->getMessage() . "\n";
}

// Test 3: Notifications include
echo "\n3. Testing includes/notifications.php...\n";
try {
    include_once 'includes/notifications.php';
    echo "   ✅ Notifications include loads successfully\n";
    echo "   ✅ Functions available:\n";
    echo "      - createInvitationNotification: " . (function_exists('createInvitationNotification') ? 'Yes' : 'No') . "\n";
    echo "      - getPendingInvitations: " . (function_exists('getPendingInvitations') ? 'Yes' : 'No') . "\n";
    echo "      - createNotificationsTable: " . (function_exists('createNotificationsTable') ? 'Yes' : 'No') . "\n";
} catch (Exception $e) {
    echo "   ❌ Error: " . $e->getMessage() . "\n";
}

echo "\n🎉 All critical files tested!\n";
echo "\nNext steps:\n";
echo "- Test companies/invitations.php in browser\n";
echo "- Test notifications/index.php in browser\n";
echo "- Verify invitation system works end-to-end\n";
?>
