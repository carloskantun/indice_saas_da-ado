<?php
/**
 * Verificador de Errores PHP - Sistema de Inclusiones
 * Verifica que no haya conflictos de funciones duplicadas
 */

echo "<!DOCTYPE html>";
echo "<html><head><title>Verificador de Errores PHP</title>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .success { color: green; font-weight: bold; }
    .error { color: red; font-weight: bold; }
    .warning { color: orange; font-weight: bold; }
    .info { color: blue; }
    pre { background: #f5f5f5; padding: 10px; border-radius: 5px; }
</style></head><body>";

echo "<h1>🔍 Verificador de Errores PHP</h1>";

echo "<h2>📋 Test de Inclusiones de Archivos</h2>";

// Test 1: Verificar config.php desde raíz
echo "<h3>1. config.php desde raíz</h3>";
try {
    if (file_exists('config.php')) {
        echo "<div class='success'>✅ config.php existe en la raíz</div>";
    } else {
        echo "<div class='error'>❌ config.php no encontrado en la raíz</div>";
    }
} catch (Exception $e) {
    echo "<div class='error'>❌ Error: " . $e->getMessage() . "</div>";
}

// Test 2: Verificar archivos de email en admin/
echo "<h3>2. Archivos de Email en admin/</h3>";
$email_files = [
    'admin/email_config.php',
    'admin/email_functions.php'
];

foreach ($email_files as $file) {
    if (file_exists($file)) {
        echo "<div class='success'>✅ $file existe</div>";
    } else {
        echo "<div class='warning'>⚠️ $file no encontrado</div>";
    }
}

// Test 3: Verificar función sendInvitationEmail (sin ejecutar)
echo "<h3>3. Test de Definición de Funciones</h3>";

try {
    // Simular inclusión de config.php
    ob_start();
    $errors_before = error_get_last();
    
    // Verificar si ya está definida
    if (function_exists('sendInvitationEmail')) {
        echo "<div class='info'>ℹ️ sendInvitationEmail() ya está definida</div>";
    } else {
        echo "<div class='info'>ℹ️ sendInvitationEmail() no está definida aún</div>";
    }
    
    ob_end_clean();
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Error en verificación: " . $e->getMessage() . "</div>";
}

// Test 4: Verificar estructura de archivos críticos
echo "<h3>4. Archivos Críticos del Sistema</h3>";
$critical_files = [
    'config.php' => 'Configuración principal',
    'admin/controller.php' => 'Controlador de administración',
    'admin/index.php' => 'Panel de administración',
    'auth/index.php' => 'Sistema de autenticación'
];

echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>Archivo</th><th>Descripción</th><th>Estado</th></tr>";

foreach ($critical_files as $file => $description) {
    echo "<tr>";
    echo "<td>$file</td>";
    echo "<td>$description</td>";
    
    if (file_exists($file)) {
        $size = filesize($file);
        echo "<td class='success'>✅ Existe ($size bytes)</td>";
    } else {
        echo "<td class='error'>❌ No encontrado</td>";
    }
    echo "</tr>";
}
echo "</table>";

// Test 5: Verificar permisos de archivos
echo "<h3>5. Permisos de Archivos</h3>";
$files_to_check = ['config.php', 'admin/controller.php', 'admin/email_config.php'];

foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        $perms = fileperms($file);
        $readable = is_readable($file) ? '✅' : '❌';
        echo "<div class='info'>$file - Lectura: $readable</div>";
    }
}

echo "<h2>🛠️ Soluciones Aplicadas</h2>";
echo "<div class='success'>";
echo "<h4>✅ Problemas Resueltos:</h4>";
echo "<ul>";
echo "<li>Eliminada inclusión duplicada de email_config.php en controller.php</li>";
echo "<li>Corregida ruta de config.php en debug.php</li>";
echo "<li>Protegidas declaraciones de funciones con if (!function_exists())</li>";
echo "</ul>";
echo "</div>";

echo "<h2>📋 Recomendaciones</h2>";
echo "<div class='info'>";
echo "<h4>Para evitar errores futuros:</h4>";
echo "<ul>";
echo "<li>Usar siempre require_once en lugar de require</li>";
echo "<li>Proteger declaraciones de funciones con if (!function_exists())</li>";
echo "<li>Verificar rutas relativas correctas según la ubicación del archivo</li>";
echo "<li>Mantener un solo punto de inclusión para archivos compartidos</li>";
echo "</ul>";
echo "</div>";

echo "<br><br>";
echo "<a href='admin/check_access.php' style='background:#007bff;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;margin-right:10px;'>Verificar Acceso Admin</a>";
echo "<a href='admin/index.php' style='background:#28a745;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;'>Ir al Panel Admin</a>";

echo "</body></html>";
?>
