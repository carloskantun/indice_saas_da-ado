-- Database fix for column name inconsistency
-- This script will standardize company names to use 'nombre' consistently

-- Check if 'name' column exists and 'nombre' doesn't exist
-- If so, rename 'name' to 'nombre'
ALTER TABLE companies CHANGE COLUMN name nombre VARCHAR(255);

-- If both columns exist (which shouldn't happen), consolidate them
-- UPDATE companies SET nombre = name WHERE nombre IS NULL OR nombre = '';
-- ALTER TABLE companies DROP COLUMN name;

-- Add any missing columns that the system expects
-- ALTER TABLE companies ADD COLUMN payment_status ENUM('active', 'pending', 'inactive') DEFAULT 'active';
