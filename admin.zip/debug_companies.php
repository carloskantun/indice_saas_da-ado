<?php
/**
 * Debug específico para companies/index.php
 */

// Mostrar todos los errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "🔍 Debug companies/index.php\n";
echo "============================\n\n";

try {
    echo "1. Verificando sesión...\n";
    session_start();
    
    if (!isset($_SESSION['user_id'])) {
        echo "❌ No hay user_id en sesión\n";
        echo "Sesión actual: " . print_r($_SESSION, true) . "\n";
        exit;
    }
    
    echo "✅ Usuario ID: " . $_SESSION['user_id'] . "\n";
    echo "✅ Usuario: " . ($_SESSION['user_name'] ?? 'Sin nombre') . "\n\n";
    
    echo "2. Verificando config.php...\n";
    require_once '../config.php';
    echo "✅ config.php cargado\n\n";
    
    echo "3. Verificando conexión DB...\n";
    $db = getDB();
    echo "✅ Conexión DB establecida\n\n";
    
    echo "4. Verificando función checkAuth...\n";
    if (function_exists('checkAuth')) {
        $auth_result = checkAuth();
        echo "✅ checkAuth existe: " . ($auth_result ? 'true' : 'false') . "\n";
    } else {
        echo "❌ checkAuth no existe\n";
    }
    echo "\n";
    
    echo "5. Verificando empresas del usuario...\n";
    $user_id = $_SESSION['user_id'];
    
    $stmt = $db->prepare("
        SELECT c.id, c.name, uc.role, uc.status 
        FROM companies c 
        INNER JOIN user_companies uc ON c.id = uc.company_id 
        WHERE uc.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $companies = $stmt->fetchAll();
    
    echo "✅ Empresas encontradas: " . count($companies) . "\n";
    foreach ($companies as $company) {
        echo "   - {$company['name']} (ID: {$company['id']}, Role: {$company['role']}, Status: {$company['status']})\n";
    }
    echo "\n";
    
    echo "6. Verificando componentes...\n";
    
    $files_to_check = [
        '../components/navbar_notifications_safe.php',
        '../includes/notifications.php'
    ];
    
    foreach ($files_to_check as $file) {
        if (file_exists($file)) {
            echo "✅ $file existe\n";
            
            // Intentar incluir para verificar sintaxis
            try {
                ob_start();
                include $file;
                $output = ob_get_clean();
                echo "   → Se incluye sin errores\n";
            } catch (Exception $e) {
                echo "   ❌ Error al incluir: " . $e->getMessage() . "\n";
            }
        } else {
            echo "❌ $file NO existe\n";
        }
    }
    echo "\n";
    
    echo "7. Test completo de companies/index.php...\n";
    
    // Cambiar al directorio correcto
    chdir('../companies/');
    
    // Capturar salida
    ob_start();
    
    try {
        // Incluir el archivo principal
        include 'index.php';
        $page_output = ob_get_clean();
        
        echo "✅ companies/index.php se ejecutó sin errores fatales\n";
        echo "📊 Tamaño de salida: " . strlen($page_output) . " bytes\n";
        
        // Verificar si hay contenido HTML básico
        if (strpos($page_output, '<html') !== false || strpos($page_output, '<!DOCTYPE') !== false) {
            echo "✅ Contiene HTML válido\n";
        } else {
            echo "⚠️  No parece contener HTML completo\n";
        }
        
        // Buscar errores comunes en la salida
        if (strpos($page_output, 'Fatal error') !== false) {
            echo "❌ Contiene errores fatales\n";
        }
        
        if (strpos($page_output, 'Warning') !== false) {
            echo "⚠️  Contiene warnings\n";
        }
        
        if (strpos($page_output, 'Notice') !== false) {
            echo "⚠️  Contiene notices\n";
        }
        
    } catch (Exception $e) {
        ob_end_clean();
        echo "❌ Error ejecutando companies/index.php: " . $e->getMessage() . "\n";
        echo "   Archivo: " . $e->getFile() . "\n";
        echo "   Línea: " . $e->getLine() . "\n";
    }
    
    echo "\n🎯 RESULTADO:\n";
    echo "=============\n";
    echo "Si ves este mensaje, el problema no es un error fatal.\n";
    echo "Posibles causas:\n";
    echo "- Problema de CSS/JavaScript que hace que la página se vea en blanco\n";
    echo "- Redirección no detectada\n";
    echo "- Problema de renderizado en el navegador\n";
    echo "\n";
    echo "Próximo paso: Verificar en el navegador si hay errores de JavaScript o CSS.\n";
    
} catch (Exception $e) {
    echo "❌ ERROR GENERAL: " . $e->getMessage() . "\n";
    echo "Archivo: " . $e->getFile() . "\n";
    echo "Línea: " . $e->getLine() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
?>
