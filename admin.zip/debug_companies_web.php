<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Debug Companies Index</title>
    <style>
        body { font-family: monospace; max-width: 1000px; margin: 0 auto; padding: 20px; background: #f8f9fa; }
        .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #28a745; background: #d4edda; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .error { color: #dc3545; background: #f8d7da; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .warning { color: #856404; background: #fff3cd; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .info { color: #0c5460; background: #d1ecf1; padding: 10px; margin: 5px 0; border-radius: 5px; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        h2 { color: #495057; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
        .btn { background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>

<div class="container">
    <h1>🔍 Debug Companies/Index.php</h1>

    <?php
    // Mostrar errores
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    try {
        echo '<h2>1. ✅ Verificación de Configuración</h2>';
        
        // Cargar config.php que maneja la sesión internamente
        require_once '../config.php';
        echo '<div class="success">✅ config.php cargado correctamente</div>';
        
        echo '<h2>2. 🔍 Verificación de Sesión</h2>';
        
        // Verificar si ya hay sesión iniciada
        if (session_status() === PHP_SESSION_ACTIVE) {
            echo '<div class="success">✅ Sesión ya está activa</div>';
        } else {
            echo '<div class="warning">⚠️ Sesión no está activa</div>';
        }
        
        // Mostrar información de sesión
        echo '<div class="info">Estado de sesión: ' . session_status() . ' (1=disabled, 2=none, 3=active)</div>';
        
        if (isset($_SESSION) && !empty($_SESSION)) {
            echo '<div class="info">📊 Variables de sesión disponibles: ' . count($_SESSION) . '</div>';
            
            if (isset($_SESSION['user_id'])) {
                echo '<div class="success">✅ Usuario ID: ' . $_SESSION['user_id'] . '</div>';
                echo '<div class="success">✅ Usuario: ' . ($_SESSION['user_name'] ?? 'Sin nombre') . '</div>';
                
                if (isset($_SESSION['company_id'])) {
                    echo '<div class="success">✅ Empresa actual: ' . $_SESSION['company_id'] . '</div>';
                }
                
                if (isset($_SESSION['current_role'])) {
                    echo '<div class="info">👤 Rol actual: ' . $_SESSION['current_role'] . '</div>';
                }
                
            } else {
                echo '<div class="error">❌ No hay user_id en sesión</div>';
                echo '<div class="info">Variables de sesión disponibles:</div>';
                echo '<pre>' . print_r($_SESSION, true) . '</pre>';
                
                // Verificar si necesita autenticación
                if (function_exists('checkAuth')) {
                    $auth_result = checkAuth();
                    echo '<div class="info">Resultado de checkAuth(): ' . ($auth_result ? 'true' : 'false') . '</div>';
                    
                    if (!$auth_result) {
                        echo '<div class="warning">🔄 Necesitas <a href="../auth/">iniciar sesión</a> primero</div>';
                        echo '</div></div></body></html>';
                        exit;
                    }
                }
            }
        } else {
            echo '<div class="error">❌ No hay variables de sesión</div>';
            echo '<div class="warning">🔄 Necesitas <a href="../auth/">iniciar sesión</a> primero</div>';
            echo '</div></div></body></html>';
            exit;
        }
        
        echo '<h2>3. 🗄️ Verificación de Base de Datos</h2>';
        $db = getDB();
        echo '<div class="success">✅ Conexión a base de datos establecida</div>';
        
        // Test básico de DB
        $stmt = $db->query("SELECT COUNT(*) FROM users");
        $user_count = $stmt->fetchColumn();
        echo '<div class="info">📊 Total usuarios en DB: ' . $user_count . '</div>';
        
        echo '<h2>4. 👤 Verificación de Usuario Actual</h2>';
        $user_id = $_SESSION['user_id'];
        
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $current_user = $stmt->fetch();
        
        if ($current_user) {
            echo '<div class="success">✅ Usuario encontrado en DB</div>';
            echo '<div class="info">📧 Email: ' . htmlspecialchars($current_user['email']) . '</div>';
            echo '<div class="info">👤 Nombre: ' . htmlspecialchars($current_user['name']) . '</div>';
        } else {
            echo '<div class="error">❌ Usuario no encontrado en DB</div>';
        }
        
        echo '<h2>5. 🏢 Verificación de Empresas</h2>';
        $stmt = $db->prepare("
            SELECT c.id, c.name, uc.role, uc.status 
            FROM companies c 
            INNER JOIN user_companies uc ON c.id = uc.company_id 
            WHERE uc.user_id = ?
        ");
        $stmt->execute([$user_id]);
        $companies = $stmt->fetchAll();
        
        echo '<div class="info">📊 Empresas del usuario: ' . count($companies) . '</div>';
        
        if (count($companies) > 0) {
            echo '<table style="width:100%; border-collapse: collapse; margin: 10px 0;">';
            echo '<tr style="background: #f8f9fa;"><th style="padding: 8px; border: 1px solid #ddd;">ID</th><th style="padding: 8px; border: 1px solid #ddd;">Nombre</th><th style="padding: 8px; border: 1px solid #ddd;">Rol</th><th style="padding: 8px; border: 1px solid #ddd;">Estado</th></tr>';
            foreach ($companies as $company) {
                echo '<tr>';
                echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $company['id'] . '</td>';
                echo '<td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($company['name']) . '</td>';
                echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $company['role'] . '</td>';
                echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $company['status'] . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        } else {
            echo '<div class="warning">⚠️ El usuario no pertenece a ninguna empresa</div>';
        }
        
        echo '<h2>6. 📁 Verificación de Archivos Componentes</h2>';
        
        $files_to_check = [
            '../components/navbar_notifications_safe.php' => 'Notificaciones navbar',
            '../includes/notifications.php' => 'Sistema de notificaciones',
            'invitations.php' => 'Gestión de invitaciones',
            'create_invitation.php' => 'Crear invitaciones'
        ];
        
        foreach ($files_to_check as $file => $description) {
            if (file_exists($file)) {
                echo '<div class="success">✅ ' . $description . ' (' . $file . ')</div>';
                
                // Verificar permisos de lectura
                if (is_readable($file)) {
                    echo '<div class="info">   → Archivo legible</div>';
                } else {
                    echo '<div class="warning">   ⚠️ Problema de permisos</div>';
                }
            } else {
                echo '<div class="error">❌ ' . $description . ' (' . $file . ') NO EXISTE</div>';
            }
        }
        
        echo '<h2>7. 🧪 Test de Carga de companies/index.php</h2>';
        
        // Verificar si podemos acceder al archivo
        if (file_exists('companies/index.php')) {
            echo '<div class="success">✅ companies/index.php existe</div>';
            
            if (is_readable('companies/index.php')) {
                echo '<div class="success">✅ companies/index.php es legible</div>';
                
                // Verificar tamaño del archivo
                $filesize = filesize('companies/index.php');
                echo '<div class="info">📊 Tamaño del archivo: ' . number_format($filesize) . ' bytes</div>';
                
                // Verificar las primeras líneas en busca de errores de sintaxis
                $first_lines = file('companies/index.php', FILE_IGNORE_NEW_LINES);
                if ($first_lines) {
                    echo '<div class="info">🔍 Primeras líneas del archivo:</div>';
                    echo '<pre>';
                    for ($i = 0; $i < min(10, count($first_lines)); $i++) {
                        echo ($i + 1) . ': ' . htmlspecialchars($first_lines[$i]) . "\n";
                    }
                    echo '</pre>';
                }
                
            } else {
                echo '<div class="error">❌ companies/index.php no es legible (permisos)</div>';
            }
        } else {
            echo '<div class="error">❌ companies/index.php NO EXISTE</div>';
        }
        
        echo '<h2>8. 🌐 Test de Navegación</h2>';
        echo '<div class="info">Si todo lo anterior está bien, el problema puede ser:</div>';
        echo '<ul>';
        echo '<li>Error de JavaScript que hace que la página se vea en blanco</li>';
        echo '<li>Problema de CSS que oculta el contenido</li>';
        echo '<li>Redirección JavaScript no detectada</li>';
        echo '<li>Error en el navegador (cache, extensiones, etc.)</li>';
        echo '</ul>';
        
        echo '<h2>🎯 Acciones Recomendadas</h2>';
        echo '<div style="margin: 20px 0;">';
        echo '<a href="companies/" class="btn">🔄 Intentar companies/ de nuevo</a>';
        echo '<a href="companies/invitations.php" class="btn">👥 Ir directamente a invitations.php</a>';
        echo '<a href="notifications/" class="btn">📧 Ver notificaciones</a>';
        echo '</div>';
        
        echo '<div class="info">';
        echo '<strong>🔧 Debugging adicional:</strong><br>';
        echo '1. Abre el inspector del navegador (F12)<br>';
        echo '2. Ve a la pestaña "Console" para ver errores de JavaScript<br>';
        echo '3. Ve a la pestaña "Network" para ver si hay problemas de carga<br>';
        echo '4. Intenta recargar la página (Ctrl+F5 o Cmd+Shift+R)';
        echo '</div>';
        
    } catch (Exception $e) {
        echo '<div class="error">';
        echo '<h3>❌ ERROR CRÍTICO</h3>';
        echo '<strong>Mensaje:</strong> ' . htmlspecialchars($e->getMessage()) . '<br>';
        echo '<strong>Archivo:</strong> ' . $e->getFile() . '<br>';
        echo '<strong>Línea:</strong> ' . $e->getLine() . '<br>';
        echo '<strong>Stack trace:</strong>';
        echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
        echo '</div>';
    }
    ?>

</div>

</body>
</html>
