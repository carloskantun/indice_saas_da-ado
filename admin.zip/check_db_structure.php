<?php
// Quick database structure check
require_once 'config.php';

try {
    $db = getDB();
    
    echo "🔍 Checking database structure...\n\n";
    
    // Check companies table structure
    $stmt = $db->query("DESCRIBE companies");
    $columns = $stmt->fetchAll();
    
    echo "📋 Companies table columns:\n";
    foreach ($columns as $column) {
        echo "  - {$column['Field']} ({$column['Type']})\n";
    }
    
    echo "\n🔍 Checking if both 'name' and 'nombre' exist...\n";
    $has_name = false;
    $has_nombre = false;
    
    foreach ($columns as $column) {
        if ($column['Field'] === 'name') $has_name = true;
        if ($column['Field'] === 'nombre') $has_nombre = true;
    }
    
    echo "  - 'name' column exists: " . ($has_name ? 'YES' : 'NO') . "\n";
    echo "  - 'nombre' column exists: " . ($has_nombre ? 'YES' : 'NO') . "\n";
    
    // Test query
    echo "\n🧪 Testing a simple SELECT query...\n";
    if ($has_nombre) {
        $stmt = $db->query("SELECT id, nombre FROM companies LIMIT 1");
        $result = $stmt->fetch();
        if ($result) {
            echo "  ✅ Successfully selected with 'nombre': " . $result['nombre'] . "\n";
        } else {
            echo "  ⚠️ No data found but query worked\n";
        }
    }
    
    if ($has_name) {
        $stmt = $db->query("SELECT id, name FROM companies LIMIT 1");
        $result = $stmt->fetch();
        if ($result) {
            echo "  ✅ Successfully selected with 'name': " . $result['name'] . "\n";
        } else {
            echo "  ⚠️ No data found but query worked\n";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
