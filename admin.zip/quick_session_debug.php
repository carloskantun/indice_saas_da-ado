<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Debug</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #f8f9fa; }
        .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #28a745; background: #d4edda; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .error { color: #dc3545; background: #f8d7da; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .warning { color: #856404; background: #fff3cd; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .info { color: #0c5460; background: #d1ecf1; padding: 10px; margin: 5px 0; border-radius: 5px; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 12px; }
        .btn { background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block; }
        .btn:hover { background: #0056b3; color: white; }
    </style>
</head>
<body>

<div class="container">
    <h1>🔍 Debug Rápido de Sesión</h1>

<?php
// Mostrar errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo '<h2>📊 Estado Inicial</h2>';
echo '<div class="info">Estado de sesión antes de config.php: ' . session_status() . '</div>';

// Cargar config sin conflictos
require_once '../config.php';

echo '<div class="success">✅ config.php cargado</div>';
echo '<div class="info">Estado de sesión después de config.php: ' . session_status() . '</div>';

// Verificar autenticación
echo '<h2>🔐 Verificación de Autenticación</h2>';

if (function_exists('checkAuth')) {
    echo '<div class="success">✅ Función checkAuth() existe</div>';
    
    $is_authenticated = checkAuth();
    echo '<div class="info">Resultado de checkAuth(): ' . ($is_authenticated ? '✅ Autenticado' : '❌ No autenticado') . '</div>';
    
    if (!$is_authenticated) {
        echo '<div class="warning">⚠️ Usuario no autenticado</div>';
        echo '<div class="info">🔄 <a href="../auth/" class="btn">Ir a Login</a></div>';
        echo '</div></body></html>';
        exit;
    }
} else {
    echo '<div class="error">❌ Función checkAuth() no existe</div>';
}

// Mostrar variables de sesión
echo '<h2>📋 Variables de Sesión</h2>';

if (isset($_SESSION) && !empty($_SESSION)) {
    echo '<div class="success">✅ Sesión activa con ' . count($_SESSION) . ' variables</div>';
    
    $session_vars = [
        'user_id' => 'ID del usuario',
        'user_name' => 'Nombre del usuario', 
        'company_id' => 'ID de empresa actual',
        'current_company_id' => 'ID de empresa actual (alt)',
        'current_role' => 'Rol actual'
    ];
    
    echo '<table style="width:100%; border-collapse: collapse; margin: 10px 0;">';
    echo '<tr style="background: #f8f9fa;"><th style="padding: 8px; border: 1px solid #ddd;">Variable</th><th style="padding: 8px; border: 1px solid #ddd;">Descripción</th><th style="padding: 8px; border: 1px solid #ddd;">Valor</th></tr>';
    
    foreach ($session_vars as $var => $desc) {
        $value = isset($_SESSION[$var]) ? $_SESSION[$var] : 'No definida';
        $status = isset($_SESSION[$var]) ? 'success' : 'error';
        $icon = isset($_SESSION[$var]) ? '✅' : '❌';
        
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>$_SESSION[\'' . $var . '\']</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $desc . '</td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd; color: ' . ($status === 'success' ? '#28a745' : '#dc3545') . ';">' . $icon . ' ' . htmlspecialchars($value) . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    
    // Verificar variables críticas
    $has_user_id = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    $has_company = isset($_SESSION['company_id']) || isset($_SESSION['current_company_id']);
    
    if ($has_user_id) {
        echo '<div class="success">✅ Usuario autenticado correctamente</div>';
        
        if ($has_company) {
            echo '<div class="success">✅ Empresa seleccionada</div>';
            echo '<h2>🎯 Acciones Disponibles</h2>';
            echo '<a href="companies/" class="btn">🏢 Panel de Empresas</a>';
            echo '<a href="companies/invitations.php" class="btn">👥 Gestionar Invitaciones</a>';
            echo '<a href="notifications/" class="btn">📧 Ver Notificaciones</a>';
        } else {
            echo '<div class="warning">⚠️ No hay empresa seleccionada</div>';
            echo '<div class="info">Necesitas seleccionar una empresa primero</div>';
        }
    } else {
        echo '<div class="error">❌ No hay usuario autenticado</div>';
        echo '<div class="info">🔄 <a href="../auth/" class="btn">Iniciar Sesión</a></div>';
    }
    
} else {
    echo '<div class="error">❌ No hay variables de sesión</div>';
    echo '<div class="info">🔄 <a href="../auth/" class="btn">Iniciar Sesión</a></div>';
}

// Test de base de datos
echo '<h2>🗄️ Test de Base de Datos</h2>';

try {
    $db = getDB();
    echo '<div class="success">✅ Conexión a base de datos exitosa</div>';
    
    // Test básico
    $stmt = $db->query("SELECT COUNT(*) as count FROM users");
    $user_count = $stmt->fetchColumn();
    echo '<div class="info">📊 Total usuarios en DB: ' . $user_count . '</div>';
    
    $stmt = $db->query("SELECT COUNT(*) as count FROM companies");
    $company_count = $stmt->fetchColumn();
    echo '<div class="info">📊 Total empresas en DB: ' . $company_count . '</div>';
    
} catch (Exception $e) {
    echo '<div class="error">❌ Error de base de datos: ' . htmlspecialchars($e->getMessage()) . '</div>';
}

// Información de debug final
echo '<h2>🔧 Información de Debug</h2>';
echo '<div class="info">📄 Archivo actual: ' . __FILE__ . '</div>';
echo '<div class="info">📁 Directorio actual: ' . __DIR__ . '</div>';
echo '<div class="info">🌐 URL actual: ' . $_SERVER['REQUEST_URI'] . '</div>';
echo '<div class="info">🕒 Fecha/Hora: ' . date('Y-m-d H:i:s') . '</div>';

?>

    <h2>💡 Próximos Pasos</h2>
    <div class="info">
        <p><strong>Si todo está en ✅ verde:</strong> El problema está en companies/index.php específicamente</p>
        <p><strong>Si hay ❌ rojos:</strong> Necesitas resolver esos problemas primero</p>
        
        <h3>🔄 Acciones de Debug:</h3>
        <ol>
            <li>Si la autenticación funciona, ir directamente a <a href="companies/invitations.php">invitations.php</a></li>
            <li>Si hay problemas de sesión, <a href="../auth/">iniciar sesión nuevamente</a></li>
            <li>Si todo funciona, el problema es CSS/JavaScript en companies/index.php</li>
        </ol>
    </div>

</div>

</body>
</html>
