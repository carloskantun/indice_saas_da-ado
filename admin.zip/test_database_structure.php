<?php
// Test database table structures and queries
require_once 'config.php';

echo "🔍 **DATABASE STRUCTURE VALIDATION**\n";
echo "=====================================\n\n";

try {
    $db = getDB();
    
    echo "1. 📋 **TABLE STRUCTURES**\n";
    echo "--------------------------\n";
    
    // Check companies table
    echo "   📄 COMPANIES table:\n";
    $stmt = $db->query("DESCRIBE companies");
    $columns = $stmt->fetchAll();
    
    $expected_companies_cols = ['id', 'name', 'description', 'status', 'created_by', 'created_at', 'updated_at', 'plan_id'];
    foreach ($expected_companies_cols as $col) {
        $exists = false;
        foreach ($columns as $column) {
            if ($column['Field'] === $col) {
                $exists = true;
                break;
            }
        }
        echo "      - $col: " . ($exists ? '✅' : '❌') . "\n";
    }
    
    // Check user_invitations table  
    echo "\n   📄 USER_INVITATIONS table:\n";
    $stmt = $db->query("DESCRIBE user_invitations");
    $columns = $stmt->fetchAll();
    
    $expected_invitations_cols = ['id', 'email', 'company_id', 'role', 'token', 'status', 'sent_by', 'sent_date', 'expiration_date', 'accepted_date'];
    foreach ($expected_invitations_cols as $col) {
        $exists = false;
        foreach ($columns as $column) {
            if ($column['Field'] === $col) {
                $exists = true;
                break;
            }
        }
        echo "      - $col: " . ($exists ? '✅' : '❌') . "\n";
    }
    
    echo "\n2. 🧪 **QUERY TESTS**\n";
    echo "--------------------\n";
    
    // Test companies query
    try {
        $stmt = $db->prepare("SELECT id, name FROM companies WHERE id = ?");
        $stmt->execute([1]);
        echo "   ✅ Companies SELECT query works\n";
    } catch (Exception $e) {
        echo "   ❌ Companies query failed: " . $e->getMessage() . "\n";
    }
    
    // Test user_invitations query
    try {
        $stmt = $db->prepare("
            SELECT i.*, u.name as inviter_name 
            FROM user_invitations i
            LEFT JOIN users u ON i.sent_by = u.id
            WHERE i.company_id = ? 
            ORDER BY i.sent_date DESC
            LIMIT 1
        ");
        $stmt->execute([1]);
        echo "   ✅ User_invitations JOIN query works\n";
    } catch (Exception $e) {
        echo "   ❌ User_invitations query failed: " . $e->getMessage() . "\n";
    }
    
    // Test invitation token validation query
    try {
        $stmt = $db->prepare("SELECT * FROM user_invitations WHERE token = ? AND email = ? AND status = 'pending' AND expiration_date > NOW()");
        $stmt->execute(['test_token', 'test@example.com']);
        echo "   ✅ Invitation validation query works\n";
    } catch (Exception $e) {
        echo "   ❌ Invitation validation query failed: " . $e->getMessage() . "\n";
    }
    
    // Test invitation insert query
    try {
        $stmt = $db->prepare("
            INSERT INTO user_invitations (company_id, sent_by, email, role, token, expiration_date) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        // Don't execute, just prepare to test syntax
        echo "   ✅ Invitation INSERT query syntax is valid\n";
    } catch (Exception $e) {
        echo "   ❌ Invitation INSERT query failed: " . $e->getMessage() . "\n";
    }
    
    echo "\n3. 📊 **DATA SAMPLES**\n";
    echo "---------------------\n";
    
    // Show some sample data
    $stmt = $db->query("SELECT COUNT(*) as count FROM companies");
    $count = $stmt->fetchColumn();
    echo "   📈 Companies count: $count\n";
    
    $stmt = $db->query("SELECT COUNT(*) as count FROM user_invitations");
    $count = $stmt->fetchColumn();
    echo "   📈 User invitations count: $count\n";
    
    $stmt = $db->query("SELECT COUNT(*) as count FROM users");
    $count = $stmt->fetchColumn();
    echo "   📈 Users count: $count\n";
    
    echo "\n🎯 **VALIDATION COMPLETE**\n";
    echo "Database structure appears to be compatible with the updated code.\n";
    
} catch (Exception $e) {
    echo "❌ Database connection error: " . $e->getMessage() . "\n";
}
?>
