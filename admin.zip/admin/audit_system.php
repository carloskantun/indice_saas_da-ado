<?php
require_once '../config.php';

echo "<h1>🔍 AUDITORÍA COMPLETA DEL SISTEMA</h1>";

// 1. Verificar usuario actual
echo "<h2>1. Usuario Actual:</h2>";
if (!checkAuth()) {
    echo "<p>❌ No autenticado</p>";
    exit;
}

$user_id = $_SESSION['user_id'];
echo "<p>User ID: $user_id</p>";
echo "<p>User Name: " . ($_SESSION['user_name'] ?? 'No definido') . "</p>";
echo "<p>User Email: " . ($_SESSION['user_email'] ?? 'No definido') . "</p>";

// 2. Verificar todos los roles del usuario en la base de datos
echo "<h2>2. Roles en Base de Datos:</h2>";
try {
    $pdo = getDB();
    
    $stmt = $pdo->prepare("
        SELECT 
            uc.company_id,
            uc.role,
            uc.status,
            c.name as company_name,
            uc.created_at,
            uc.last_accessed
        FROM user_companies uc
        INNER JOIN companies c ON uc.company_id = c.id
        WHERE uc.user_id = ?
        ORDER BY uc.role, c.name
    ");
    $stmt->execute([$user_id]);
    $user_roles = $stmt->fetchAll();
    
    if ($user_roles) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Empresa</th><th>Rol</th><th>Estado</th><th>Creado</th><th>Último Acceso</th></tr>";
        foreach ($user_roles as $role) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($role['company_name']) . " (ID: " . $role['company_id'] . ")</td>";
            echo "<td><strong>" . htmlspecialchars($role['role']) . "</strong></td>";
            echo "<td>" . htmlspecialchars($role['status']) . "</td>";
            echo "<td>" . ($role['created_at'] ?? 'N/A') . "</td>";
            echo "<td>" . ($role['last_accessed'] ?? 'Nunca') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>❌ No se encontraron roles para este usuario</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error consultando roles: " . $e->getMessage() . "</p>";
}

// 3. Verificar función checkRole
echo "<h2>3. Verificación de Función checkRole:</h2>";
echo "<p>¿Función checkRole existe? " . (function_exists('checkRole') ? "✅ Sí" : "❌ No") . "</p>";

if (function_exists('checkRole')) {
    $roles_to_test = ['root', 'superadmin', 'admin', 'moderator', 'user'];
    foreach ($roles_to_test as $role) {
        $has_role = checkRole([$role]);
        echo "<p>¿Tiene rol '$role'? " . ($has_role ? "✅ Sí" : "❌ No") . "</p>";
    }
    
    // Test combinado
    $has_admin_access = checkRole(['root', 'superadmin', 'admin']);
    echo "<p><strong>¿Puede acceder al panel admin?</strong> " . ($has_admin_access ? "✅ Sí" : "❌ No") . "</p>";
}

// 4. Verificar sesión completa
echo "<h2>4. Estado Completo de la Sesión:</h2>";
echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>Clave</th><th>Valor</th></tr>";
foreach ($_SESSION as $key => $value) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($key) . "</td>";
    echo "<td>" . htmlspecialchars(is_array($value) ? json_encode($value) : $value) . "</td>";
    echo "</tr>";
}
echo "</table>";

// 5. Verificar archivos del panel de administración
echo "<h2>5. Archivos del Panel de Administración:</h2>";
$admin_files = ['usuarios.php', 'permisos.php', 'roles.php', 'controller.php'];
foreach ($admin_files as $file) {
    $exists = file_exists($file);
    $readable = $exists ? is_readable($file) : false;
    echo "<p>$file: " . ($exists ? "✅ Existe" : "❌ No existe") . " - " . ($readable ? "✅ Legible" : "❌ No legible") . "</p>";
}

// 6. Test directo de acceso a controller.php
echo "<h2>6. Test de Controller.php:</h2>";
echo "<p>Simulando acceso a controller.php...</p>";

// Simular los checks que hace controller.php
$can_access_controller = checkRole(['root', 'superadmin', 'admin']);
echo "<p>¿Pasa verificación de roles? " . ($can_access_controller ? "✅ Sí" : "❌ No") . "</p>";

$needs_company = !checkRole(['root', 'superadmin']);
$has_company = isset($_SESSION['current_company_id']) && !empty($_SESSION['current_company_id']);

echo "<p>¿Necesita empresa activa? " . ($needs_company ? "✅ Sí" : "❌ No") . "</p>";
echo "<p>¿Tiene empresa activa? " . ($has_company ? "✅ Sí" : "❌ No") . "</p>";

if ($needs_company && !$has_company) {
    echo "<p>❌ <strong>PROBLEMA:</strong> Necesita empresa activa pero no la tiene</p>";
} else {
    echo "<p>✅ <strong>OK:</strong> Puede acceder al controller</p>";
}

// 7. Test de establecimiento de empresa
echo "<h2>7. Test de Establecimiento de Empresa:</h2>";
if (isset($_GET['test_company'])) {
    $test_company_id = intval($_GET['test_company']);
    
    try {
        $stmt = $pdo->prepare("SELECT id, name FROM companies WHERE id = ? AND status = 'active'");
        $stmt->execute([$test_company_id]);
        $company = $stmt->fetch();
        
        if ($company) {
            $_SESSION['current_company_id'] = $company['id'];
            $_SESSION['current_company_name'] = $company['name'];
            echo "<div style='background: #d4edda; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
            echo "✅ Empresa de prueba establecida: " . htmlspecialchars($company['name']);
            echo "</div>";
            
            // Refrescar página para ver cambios
            echo "<script>setTimeout(function(){ location.reload(); }, 2000);</script>";
        } else {
            echo "<p>❌ Empresa de prueba no encontrada</p>";
        }
    } catch (Exception $e) {
        echo "<p>❌ Error: " . $e->getMessage() . "</p>";
    }
} else {
    // Mostrar empresas disponibles para test
    try {
        if (checkRole(['root'])) {
            $stmt = $pdo->prepare("SELECT id, name FROM companies WHERE status = 'active' ORDER BY name LIMIT 3");
            $stmt->execute();
        } else {
            $stmt = $pdo->prepare("
                SELECT DISTINCT c.id, c.name 
                FROM companies c
                INNER JOIN user_companies uc ON c.id = uc.company_id
                WHERE c.status = 'active' AND uc.user_id = ? AND uc.status = 'active'
                ORDER BY c.name LIMIT 3
            ");
            $stmt->execute([$user_id]);
        }
        
        $companies = $stmt->fetchAll();
        if ($companies) {
            echo "<p>Empresas disponibles para test:</p>";
            echo "<ul>";
            foreach ($companies as $company) {
                $test_url = "?test_company=" . $company['id'];
                echo "<li><a href='$test_url'>" . htmlspecialchars($company['name']) . " (ID: " . $company['id'] . ")</a></li>";
            }
            echo "</ul>";
        }
    } catch (Exception $e) {
        echo "<p>❌ Error: " . $e->getMessage() . "</p>";
    }
}

echo "<br><br>";
echo "<a href='test_access.php'>🔙 Volver a Test Access</a> | ";
echo "<a href='../companies/simple_test.php'>🔙 Volver a Simple Test</a>";
?>
