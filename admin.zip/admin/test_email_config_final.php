<?php
require_once '../config.php';

echo "<h2>🔧 Test de Email Configuration - Corregido</h2>";

try {
    echo "<div style='padding: 15px; background: #e7f3ff; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>✅ Test 1: Cargar Configuración de Email</h3>";
    
    // Incluir configuración de email
    require_once __DIR__ . '/email_config.php';
    
    echo "<p>✅ Configuración cargada exitosamente</p>";
    
    // Verificar constantes
    if (defined('MAIL_FROM_EMAIL')) {
        echo "<p>✅ MAIL_FROM_EMAIL: " . MAIL_FROM_EMAIL . "</p>";
    } else {
        echo "<p>❌ MAIL_FROM_EMAIL no definido</p>";
    }
    
    if (defined('MAIL_FROM_NAME')) {
        echo "<p>✅ MAIL_FROM_NAME: " . MAIL_FROM_NAME . "</p>";
    } else {
        echo "<p>❌ MAIL_FROM_NAME no definido</p>";
    }
    
    if (defined('MAIL_REPLY_TO')) {
        echo "<p>✅ MAIL_REPLY_TO: " . MAIL_REPLY_TO . "</p>";
    } else {
        echo "<p>❌ MAIL_REPLY_TO no definido</p>";
    }
    
    echo "</div>";

} catch (ParseError $e) {
    echo "<div style='padding: 15px; background: #fef2f2; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>❌ Error de Sintaxis</h3>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Archivo:</strong> " . $e->getFile() . "</p>";
    echo "<p><strong>Línea:</strong> " . $e->getLine() . "</p>";
    echo "</div>";
} catch (Exception $e) {
    echo "<div style='padding: 15px; background: #fef2f2; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>❌ Error General</h3>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "<div style='padding: 15px; background: #f0f9ff; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>🔧 Test 2: Verificar Sistema de Mail</h3>";

try {
    if (function_exists('mail')) {
        echo "<p>✅ Función mail() disponible</p>";
        
        // Test básico de headers
        $test_headers = [
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . (defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'Test') . ' <' . (defined('MAIL_FROM_EMAIL') ? MAIL_FROM_EMAIL : 'test@test.com') . '>',
            'X-Mailer: PHP/' . phpversion()
        ];
        
        echo "<p>✅ Headers generados correctamente:</p>";
        echo "<pre style='background: #f8f9fa; padding: 10px; font-size: 12px;'>";
        foreach ($test_headers as $header) {
            echo htmlspecialchars($header) . "\n";
        }
        echo "</pre>";
        
    } else {
        echo "<p>❌ Función mail() NO disponible</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error verificando sistema de mail: " . $e->getMessage() . "</p>";
}

echo "</div>";

echo "<div style='padding: 15px; background: #f0fdf4; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>📧 Test 3: Simulación de Email</h3>";

if (defined('MAIL_FROM_EMAIL')) {
    $test_email = "test@example.com";
    $test_subject = "Test Email de " . MAIL_FROM_NAME;
    $test_html = "<!DOCTYPE html>
<html>
<head><meta charset='UTF-8'><title>Test</title></head>
<body>
    <h2>Email de Prueba</h2>
    <p>Este es un email de prueba del sistema.</p>
    <p>Configuración funcionando correctamente.</p>
</body>
</html>";

    echo "<p>✅ Email de prueba generado:</p>";
    echo "<ul>";
    echo "<li><strong>Para:</strong> " . htmlspecialchars($test_email) . "</li>";
    echo "<li><strong>Asunto:</strong> " . htmlspecialchars($test_subject) . "</li>";
    echo "<li><strong>De:</strong> " . MAIL_FROM_NAME . " &lt;" . MAIL_FROM_EMAIL . "&gt;</li>";
    echo "</ul>";
    
    echo "<details>";
    echo "<summary>Ver contenido HTML</summary>";
    echo "<pre style='background: #f8f9fa; padding: 10px; font-size: 12px; max-height: 200px; overflow-y: auto;'>";
    echo htmlspecialchars($test_html);
    echo "</pre>";
    echo "</details>";
    
} else {
    echo "<p>❌ No se puede generar email de prueba sin configuración</p>";
}

echo "</div>";

echo "<div style='padding: 15px; background: #fffbeb; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>📋 Resumen</h3>";

$all_good = defined('MAIL_FROM_EMAIL') && defined('MAIL_FROM_NAME') && defined('MAIL_REPLY_TO') && function_exists('mail');

if ($all_good) {
    echo "<p style='color: green; font-weight: bold;'>✅ CONFIGURACIÓN DE EMAIL FUNCIONANDO CORRECTAMENTE</p>";
    echo "<p>El sistema está listo para enviar invitaciones por email.</p>";
} else {
    echo "<p style='color: red; font-weight: bold;'>❌ PROBLEMAS EN CONFIGURACIÓN DE EMAIL</p>";
    echo "<p>Revisa los errores anteriores para corregir la configuración.</p>";
}

echo "</div>";

echo "<hr>";
echo "<p><a href='../companies/'>🔙 Volver a Companies</a></p>";
echo "<p><a href='sistema_selector_empresas_completo.php'>📊 Dashboard Completo</a></p>";
?>
