<?php
require_once '../config.php';

echo "<h1>🚀 ENLACES DIRECTOS AL PANEL</h1>";

// Verificar autenticación
if (!checkAuth()) {
    echo "<p>❌ No autenticado</p>";
    exit;
}

echo "<p>✅ Usuario: " . $_SESSION['user_name'] . "</p>";
echo "<p>✅ Rol: " . ($_SESSION['current_role'] ?? 'No definido') . "</p>";

// Usar company_id de la sesión
$company_id = $_SESSION['company_id'] ?? $_SESSION['current_company_id'] ?? null;

if ($company_id) {
    echo "<h2>🎯 Enlaces Directos (Company ID: $company_id):</h2>";
    echo "<div style='background: #e7f3ff; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>Panel de Administración:</h3>";
    echo "<ul style='list-style: none; padding: 0;'>";
    echo "<li style='margin: 10px 0;'><a href='usuarios.php?company_id=$company_id' target='_blank' style='background: #007bff; color: white; padding: 8px 15px; text-decoration: none; border-radius: 3px;'>🧑‍💼 Gestión de Usuarios</a></li>";
    echo "<li style='margin: 10px 0;'><a href='permisos.php?company_id=$company_id' target='_blank' style='background: #28a745; color: white; padding: 8px 15px; text-decoration: none; border-radius: 3px;'>🔐 Gestión de Permisos</a></li>";
    echo "<li style='margin: 10px 0;'><a href='roles.php?company_id=$company_id' target='_blank' style='background: #ffc107; color: black; padding: 8px 15px; text-decoration: none; border-radius: 3px;'>👥 Gestión de Roles</a></li>";
    echo "</ul>";
    echo "</div>";
    
    // Test del controller
    echo "<h3>🔧 Test del Controller:</h3>";
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 3px; margin: 10px 0;'>";
    echo "<p><a href='controller.php?action=get_users_by_company&company_id=$company_id' target='_blank'>Test Controller - Obtener Usuarios</a></p>";
    echo "</div>";
} else {
    echo "<h2>❌ No hay Company ID disponible</h2>";
    echo "<p>Valores en sesión:</p>";
    echo "<ul>";
    echo "<li>current_company_id: " . ($_SESSION['current_company_id'] ?? 'No definido') . "</li>";
    echo "<li>company_id: " . ($_SESSION['company_id'] ?? 'No definido') . "</li>";
    echo "</ul>";
}

// Mostrar empresas disponibles para establecer
echo "<h2>🏢 Empresas Disponibles:</h2>";
try {
    $pdo = getDB();
    $stmt = $pdo->prepare("
        SELECT DISTINCT c.id, c.name 
        FROM companies c
        INNER JOIN user_companies uc ON c.id = uc.company_id
        WHERE c.status = 'active' AND uc.user_id = ? AND uc.status = 'active'
        ORDER BY c.name
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $companies = $stmt->fetchAll();
    
    if ($companies) {
        foreach ($companies as $company) {
            $direct_links = "
                <div style='background: #f1f3f4; padding: 10px; margin: 10px 0; border-radius: 5px;'>
                    <h4>{$company['name']} (ID: {$company['id']})</h4>
                    <p>
                        <a href='usuarios.php?company_id={$company['id']}' target='_blank'>👨‍💼 Usuarios</a> | 
                        <a href='permisos.php?company_id={$company['id']}' target='_blank'>🔐 Permisos</a> | 
                        <a href='roles.php?company_id={$company['id']}' target='_blank'>👥 Roles</a>
                    </p>
                </div>
            ";
            echo $direct_links;
        }
    } else {
        echo "<p>❌ No se encontraron empresas</p>";
    }
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<br><br>";
echo "<a href='test_access.php'>🔙 Test Access</a> | ";
echo "<a href='audit_system.php'>🔍 Auditoría</a> | ";
echo "<a href='../companies/simple_test.php'>🏠 Simple Test</a>";
?>
