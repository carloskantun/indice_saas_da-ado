<?php
/**
 * Test rápido para verificar que email_config.php funciona sin errores
 */

echo "🧪 Probando configuración de email...\n\n";

try {
    // Incluir config
    require_once '../config.php';
    echo "✅ config.php cargado correctamente\n";
    
    // Incluir email config
    require_once 'email_config.php';
    echo "✅ email_config.php cargado correctamente\n";
    
    // Verificar constantes básicas
    if (defined('MAIL_FROM_EMAIL')) {
        echo "✅ MAIL_FROM_EMAIL definido: " . MAIL_FROM_EMAIL . "\n";
    } else {
        echo "❌ MAIL_FROM_EMAIL no definido\n";
    }
    
    if (defined('MAIL_FROM_NAME')) {
        echo "✅ MAIL_FROM_NAME definido: " . MAIL_FROM_NAME . "\n";
    } else {
        echo "❌ MAIL_FROM_NAME no definido\n";
    }
    
    // Verificar funciones
    if (function_exists('sendInvitationEmail')) {
        echo "✅ Función sendInvitationEmail disponible\n";
    } else {
        echo "❌ Función sendInvitationEmail no disponible\n";
    }
    
    if (function_exists('sendTestEmail')) {
        echo "✅ Función sendTestEmail disponible\n";
    } else {
        echo "❌ Función sendTestEmail no disponible\n";
    }
    
    if (function_exists('sendEmail')) {
        echo "✅ Función sendEmail disponible\n";
    } else {
        echo "❌ Función sendEmail no disponible\n";
    }
    
    echo "\n🎉 ¡Todo funciona correctamente!\n";
    echo "📧 El sistema de email está listo para usar.\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "📍 Archivo: " . $e->getFile() . "\n";
    echo "📍 Línea: " . $e->getLine() . "\n";
}

echo "\n🔚 Test completado.\n";
?>
