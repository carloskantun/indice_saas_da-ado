<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalar Tabla User Invitations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-info text-white text-center">
                        <h4><i class="fas fa-database"></i> Instalar Tabla User Invitations</h4>
                    </div>
                    <div class="card-body text-center">
                        <p class="mb-4">Se necesita crear la tabla <code>user_invitations</code> para el correcto funcionamiento del sistema.</p>
                        
                        <button class="btn btn-primary btn-lg" onclick="installTable()">
                            <i class="fas fa-download"></i> Crear Tabla User Invitations
                        </button>
                        
                        <div id="result" class="mt-4"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function installTable() {
            const button = document.querySelector('button');
            const result = document.getElementById('result');
            
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creando tabla...';
            
            try {
                const response = await fetch('install_user_invitations_table.php');
                const data = await response.json();
                
                if (data.success) {
                    result.innerHTML = `
                        <div class="alert alert-success">
                            <h5><i class="fas fa-check-circle"></i> ¡Tabla creada exitosamente!</h5>
                            <p>${data.message}</p>
                            <a href="index.php" class="btn btn-success">
                                <i class="fas fa-arrow-right"></i> Ir al Panel Admin
                            </a>
                        </div>
                    `;
                } else {
                    result.innerHTML = `
                        <div class="alert alert-danger">
                            <h5><i class="fas fa-times-circle"></i> Error</h5>
                            <p>${data.message}</p>
                        </div>
                    `;
                    button.disabled = false;
                    button.innerHTML = '<i class="fas fa-download"></i> Crear Tabla User Invitations';
                }
            } catch (error) {
                result.innerHTML = `
                    <div class="alert alert-danger">
                        <h5><i class="fas fa-times-circle"></i> Error de Conexión</h5>
                        <p>No se pudo crear la tabla. Verifica tu conexión.</p>
                    </div>
                `;
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-download"></i> Crear Tabla User Invitations';
            }
        }
    </script>
</body>
</html>
