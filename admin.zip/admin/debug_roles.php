<?php
/**
 * Debug rápido para verificar roles y sesión
 */
require_once '../config.php';

echo "<h1>🔍 Debug Roles y Sesión</h1>";

if (!checkAuth()) {
    echo "<p>❌ Usuario no autenticado</p>";
    exit;
}

echo "<h3>📊 Variables de Sesión:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h3>🔐 Verificación de Roles:</h3>";
$db = getDB();
$user_id = $_SESSION['user_id'];

$stmt = $db->prepare("
    SELECT uc.role, c.name as company_name, uc.status
    FROM user_companies uc 
    INNER JOIN companies c ON uc.company_id = c.id
    WHERE uc.user_id = ?
    ORDER BY 
        CASE uc.role 
            WHEN 'superadmin' THEN 1 
            WHEN 'admin' THEN 2 
            WHEN 'manager' THEN 3 
            WHEN 'user' THEN 4 
            ELSE 5 
        END
");
$stmt->execute([$user_id]);
$roles = $stmt->fetchAll();

if ($roles) {
    echo "<table class='table table-striped'>";
    echo "<tr><th>Empresa</th><th>Rol</th><th>Estado</th></tr>";
    foreach ($roles as $role) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($role['company_name']) . "</td>";
        echo "<td><span class='badge bg-primary'>" . htmlspecialchars($role['role']) . "</span></td>";
        echo "<td>" . htmlspecialchars($role['status']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    $highestRole = $roles[0]['role'];
    echo "<p><strong>Rol más alto:</strong> <span class='badge bg-success'>$highestRole</span></p>";
    
    if ($highestRole === 'superadmin') {
        echo "<p>✅ El usuario PUEDE acceder al panel de administración</p>";
        echo "<p><a href='index.php' class='btn btn-primary'>🏢 Ir al Panel Admin</a></p>";
    } else {
        echo "<p>❌ El usuario NO puede acceder al panel de administración (necesita rol superadmin)</p>";
    }
} else {
    echo "<p>❌ No se encontraron roles para este usuario</p>";
}

echo "<p><a href='../companies/' class='btn btn-secondary'>🔙 Volver a Companies</a></p>";
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div class="container mt-4"><?php echo isset($output) ? $output : ''; ?></div>
