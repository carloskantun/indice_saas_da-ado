<?php
/**
 * Instalador para tabla user_invitations
 */

require_once '../config.php';
require_once 'db_connection.php';

header('Content-Type: application/json');

try {
    $pdo = getDB();
    
    // Verificar si la tabla ya existe
    $stmt = $pdo->query("SHOW TABLES LIKE 'user_invitations'");
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'La tabla user_invitations ya existe.'
        ]);
        exit();
    }
    
    // Crear la tabla
    $sql = "
    CREATE TABLE IF NOT EXISTS `user_invitations` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `email` varchar(255) NOT NULL,
        `company_id` int(11) NOT NULL,
        `unit_id` int(11) DEFAULT NULL,
        `business_id` int(11) DEFAULT NULL,
        `role` enum('superadmin','admin','moderator','user') NOT NULL DEFAULT 'user',
        `token` varchar(64) NOT NULL,
        `status` enum('pending','accepted','expired','cancelled') NOT NULL DEFAULT 'pending',
        `sent_by` int(11) NOT NULL,
        `sent_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `expiration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `accepted_date` timestamp NULL DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_token` (`token`),
        KEY `idx_company_status` (`company_id`, `status`),
        KEY `idx_expiration` (`expiration_date`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    $pdo->exec($sql);
    
    // Crear trigger para establecer automáticamente la fecha de expiración
    $trigger_sql = "
    CREATE TRIGGER IF NOT EXISTS `set_expiration_date` 
    BEFORE INSERT ON `user_invitations`
    FOR EACH ROW 
    BEGIN
        IF NEW.expiration_date = NEW.sent_date THEN
            SET NEW.expiration_date = DATE_ADD(NEW.sent_date, INTERVAL 48 HOUR);
        END IF;
    END;
    ";
    
    $pdo->exec($trigger_sql);
    
    echo json_encode([
        'success' => true,
        'message' => 'Tabla user_invitations creada exitosamente.'
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
