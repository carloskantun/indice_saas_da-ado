<?php
echo "<h2>🔍 Test de Diagnóstico - email_config.php</h2>";

echo "<div style='padding: 15px; background: #e7f3ff; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>Test 1: Verificar archivo email_config.php</h3>";

try {
    echo "<p>Intentando incluir email_config.php...</p>";
    
    // Test básico sin incluir el archivo
    echo "<p>✅ Archivo test_email_debug.php ejecutándose correctamente</p>";
    
    // Verificar si el archivo existe
    $config_file = __DIR__ . '/email_config.php';
    if (file_exists($config_file)) {
        echo "<p>✅ Archivo email_config.php encontrado</p>";
        
        // Leer el contenido del archivo para verificar
        $content = file_get_contents($config_file);
        $lines = explode("\n", $content);
        echo "<p>✅ Archivo tiene " . count($lines) . " líneas</p>";
        
        // Verificar línea 24 específicamente
        if (isset($lines[23])) { // Array es 0-based, línea 24 = índice 23
            echo "<p><strong>Línea 24:</strong> <code>" . htmlspecialchars($lines[23]) . "</code></p>";
        }
        
        // Verificar las líneas alrededor
        echo "<h4>Líneas 20-30:</h4>";
        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 3px;'>";
        for ($i = 19; $i < 30 && $i < count($lines); $i++) {
            $line_num = $i + 1;
            $highlight = ($line_num == 24) ? 'background: yellow;' : '';
            echo "<span style='$highlight'>$line_num: " . htmlspecialchars($lines[$i]) . "</span>\n";
        }
        echo "</pre>";
        
    } else {
        echo "<p>❌ Archivo email_config.php NO encontrado en: $config_file</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error en test básico: " . $e->getMessage() . "</p>";
}
echo "</div>";

echo "<div style='padding: 15px; background: #f0f9ff; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>Test 2: Intentar incluir email_config.php</h3>";

try {
    echo "<p>Incluyendo email_config.php...</p>";
    
    // Capturar cualquier output o error
    ob_start();
    include_once __DIR__ . '/email_config.php';
    $output = ob_get_clean();
    
    echo "<p>✅ Archivo incluido exitosamente</p>";
    if ($output) {
        echo "<p>Output del archivo: <code>" . htmlspecialchars($output) . "</code></p>";
    }
    
    // Verificar si las constantes se definieron
    $constants = ['MAIL_FROM_EMAIL', 'MAIL_FROM_NAME', 'MAIL_REPLY_TO'];
    foreach ($constants as $const) {
        if (defined($const)) {
            echo "<p>✅ Constante $const definida: " . constant($const) . "</p>";
        } else {
            echo "<p>❌ Constante $const NO definida</p>";
        }
    }
    
} catch (ParseError $e) {
    echo "<p>❌ Error de sintaxis: " . $e->getMessage() . "</p>";
    echo "<p>Archivo: " . $e->getFile() . "</p>";
    echo "<p>Línea: " . $e->getLine() . "</p>";
} catch (Exception $e) {
    echo "<p>❌ Error general: " . $e->getMessage() . "</p>";
}
echo "</div>";

echo "<div style='padding: 15px; background: #f0fdf4; border-radius: 5px; margin: 10px 0;'>";
echo "<h3>Test 3: Verificar email_functions.php</h3>";

try {
    $functions_file = __DIR__ . '/email_functions.php';
    if (file_exists($functions_file)) {
        echo "<p>✅ Archivo email_functions.php encontrado</p>";
        
        // Verificar sintaxis sin ejecutar
        $content = file_get_contents($functions_file);
        
        // Buscar posibles problemas
        if (strpos($content, '<!DOCTYPE') !== false) {
            echo "<p>⚠️ Se encontró HTML en email_functions.php</p>";
        }
        
        if (strpos($content, '<?php') === false) {
            echo "<p>❌ No se encontró etiqueta PHP de apertura</p>";
        }
        
        // Contar etiquetas PHP
        $php_open = substr_count($content, '<?php');
        $php_close = substr_count($content, '?>');
        echo "<p>Etiquetas PHP: <?php($php_open) ?>($php_close)</p>";
        
    } else {
        echo "<p>❌ Archivo email_functions.php NO encontrado</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error verificando email_functions.php: " . $e->getMessage() . "</p>";
}
echo "</div>";

echo "<hr>";
echo "<p><a href='../companies/'>🔙 Volver a Companies</a></p>";
?>
