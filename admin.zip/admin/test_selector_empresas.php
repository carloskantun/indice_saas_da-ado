<?php
require_once '../config.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Selector de Empresas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-info text-white">
                <h3><i class="fas fa-building me-2"></i>Test Selector de Empresas</h3>
            </div>
            <div class="card-body">
                
                <!-- Estado Actual -->
                <div class="alert alert-info">
                    <h5><i class="fas fa-info-circle me-2"></i>Estado Actual de la Sesión</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>User ID:</strong> <?= $_SESSION['user_id'] ?? 'No definido' ?></p>
                            <p><strong>User Name:</strong> <?= $_SESSION['user_name'] ?? 'No definido' ?></p>
                            <p><strong>Current Role:</strong> <?= $_SESSION['current_role'] ?? 'No definido' ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Company ID:</strong> <?= $_SESSION['company_id'] ?? 'No definido' ?></p>
                            <p><strong>Current Company ID:</strong> <?= $_SESSION['current_company_id'] ?? 'No definido' ?></p>
                            <p><strong>User Role:</strong> <?= $_SESSION['user_role'] ?? 'No definido' ?></p>
                        </div>
                    </div>
                </div>

                <!-- Empresas Disponibles -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-list me-2"></i>Empresas Disponibles para el Usuario</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            $pdo = getDB();
                            $stmt = $pdo->prepare("
                                SELECT c.id, c.name, c.description, uc.role, uc.status, uc.last_accessed
                                FROM companies c 
                                INNER JOIN user_companies uc ON c.id = uc.company_id 
                                WHERE uc.user_id = ? AND uc.status = 'active'
                                ORDER BY uc.last_accessed DESC, c.name
                            ");
                            $stmt->execute([$_SESSION['user_id']]);
                            $user_companies = $stmt->fetchAll();
                            
                            $current_company_id = $_SESSION['current_company_id'] ?? $_SESSION['company_id'] ?? null;
                        ?>
                        
                        <?php if ($user_companies): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Empresa</th>
                                        <th>Descripción</th>
                                        <th>Rol</th>
                                        <th>Estado</th>
                                        <th>Último Acceso</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($user_companies as $company): ?>
                                    <tr class="<?= $company['id'] == $current_company_id ? 'table-success' : '' ?>">
                                        <td>
                                            <strong><?= $company['id'] ?></strong>
                                            <?php if ($company['id'] == $current_company_id): ?>
                                                <i class="fas fa-check-circle text-success ms-1" title="Empresa activa"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($company['name']) ?></strong>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?= htmlspecialchars($company['description'] ?: 'Sin descripción') ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?= $company['role'] === 'root' ? 'danger' : 
                                                ($company['role'] === 'superadmin' ? 'warning' : 
                                                ($company['role'] === 'admin' ? 'primary' : 'secondary')) ?>">
                                                <?= htmlspecialchars($company['role']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-success"><?= htmlspecialchars($company['status']) ?></span>
                                        </td>
                                        <td>
                                            <small><?= $company['last_accessed'] ? date('d/m/Y H:i', strtotime($company['last_accessed'])) : 'Nunca' ?></small>
                                        </td>
                                        <td>
                                            <div class="btn-group-sm" role="group">
                                                <?php if ($company['id'] != $current_company_id): ?>
                                                <a href="../companies/?switch_company=<?= $company['id'] ?>" 
                                                   class="btn btn-sm btn-outline-primary"
                                                   onclick="return confirm('¿Establecer como empresa activa?')">
                                                    <i class="fas fa-check me-1"></i>Activar
                                                </a>
                                                <?php else: ?>
                                                <span class="badge bg-success">Activa</span>
                                                <?php endif; ?>
                                                
                                                <?php if (checkRole(['root', 'superadmin', 'admin'])): ?>
                                                <a href="../admin/?company_id=<?= $company['id'] ?>" 
                                                   class="btn btn-sm btn-outline-success" target="_blank">
                                                    <i class="fas fa-cog me-1"></i>Admin
                                                </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            No se encontraron empresas para este usuario.
                        </div>
                        <?php endif; ?>
                        
                        <?php } else { ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-times-circle me-2"></i>
                            No hay sesión activa.
                        </div>
                        <?php } ?>
                    </div>
                </div>

                <!-- Simulador de Cambio -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-exchange-alt me-2"></i>Simulador de Cambio de Empresa</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="../companies/">
                            <div class="row">
                                <div class="col-md-8">
                                    <select name="switch_company" class="form-select" required>
                                        <option value="">Seleccionar empresa...</option>
                                        <?php if (isset($user_companies)): ?>
                                            <?php foreach ($user_companies as $company): ?>
                                                <option value="<?= $company['id'] ?>" 
                                                        <?= $company['id'] == $current_company_id ? 'disabled' : '' ?>>
                                                    <?= htmlspecialchars($company['name']) ?> 
                                                    (<?= ucfirst($company['role']) ?>)
                                                    <?= $company['id'] == $current_company_id ? ' - ACTIVA' : '' ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-exchange-alt me-1"></i>Cambiar Empresa
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Enlaces de Prueba -->
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-link me-2"></i>Enlaces de Prueba con Empresa Actual</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($current_company_id): ?>
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Panel de Administración</h6>
                                <div class="d-grid gap-2">
                                    <a href="../admin/?company_id=<?= $current_company_id ?>" class="btn btn-outline-primary" target="_blank">
                                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard Admin
                                    </a>
                                    <a href="../admin/usuarios.php?company_id=<?= $current_company_id ?>" class="btn btn-outline-success" target="_blank">
                                        <i class="fas fa-users me-2"></i>Gestión Usuarios
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6>Otros Enlaces</h6>
                                <div class="d-grid gap-2">
                                    <a href="../units/?company_id=<?= $current_company_id ?>" class="btn btn-outline-info" target="_blank">
                                        <i class="fas fa-sitemap me-2"></i>Unidades
                                    </a>
                                    <a href="../companies/" class="btn btn-outline-secondary">
                                        <i class="fas fa-building me-2"></i>Lista de Empresas
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            No hay empresa activa seleccionada. Selecciona una empresa arriba para probar los enlaces.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Navegación -->
                <div class="text-center mt-4">
                    <a href="../companies/" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-2"></i>Volver a Companies
                    </a>
                    <a href="../admin/sistema_final.php" class="btn btn-outline-success">
                        <i class="fas fa-chart-bar me-2"></i>Sistema Final
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
