<?php
require_once '../config.php';

echo "<h2>Test de Navegación y Roles</h2>";

echo "<h3>Estado de la Sesión:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h3>Pruebas de Roles:</h3>";
$roles_to_test = ['root', 'superadmin', 'admin', 'moderator', 'user'];

foreach ($roles_to_test as $role) {
    $has_role = checkRole([$role]);
    echo "Rol '$role': " . ($has_role ? "✅ SÍ" : "❌ NO") . "<br>";
}

echo "<h3>Pruebas de Múltiples Roles:</h3>";
$multi_roles = [
    ['root', 'superadmin'],
    ['superadmin', 'admin'],
    ['admin', 'moderator'],
    ['root', 'superadmin', 'admin']
];

foreach ($multi_roles as $roles) {
    $has_any = checkRole($roles);
    echo "Roles [" . implode(', ', $roles) . "]: " . ($has_any ? "✅ SÍ" : "❌ NO") . "<br>";
}

echo "<h3>Enlaces de Prueba:</h3>";
echo "<ul>";
echo "<li><a href='/companies/'>Companies Index</a></li>";
echo "<li><a href='/admin/?company_id=1'>Admin Panel (Company 1)</a></li>";
echo "<li><a href='/admin/usuarios.php?company_id=1'>Usuarios (Company 1)</a></li>";
echo "<li><a href='/admin/roles.php?company_id=1'>Roles (Company 1)</a></li>";
echo "<li><a href='/admin/permisos.php?company_id=1'>Permisos (Company 1)</a></li>";
echo "</ul>";

echo "<h3>Información de Usuario:</h3>";
if (isset($_SESSION['user_id'])) {
    $pdo = getDB();
    $stmt = $pdo->prepare("
        SELECT u.*, uc.role, uc.company_id, c.name as company_name
        FROM users u 
        LEFT JOIN user_companies uc ON u.id = uc.user_id AND uc.status = 'active'
        LEFT JOIN companies c ON uc.company_id = c.id
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user_companies = $stmt->fetchAll();
    
    echo "<h4>Empresas del Usuario:</h4>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Company ID</th><th>Company Name</th><th>Role</th></tr>";
    foreach ($user_companies as $uc) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($uc['company_id']) . "</td>";
        echo "<td>" . htmlspecialchars($uc['company_name']) . "</td>";
        echo "<td>" . htmlspecialchars($uc['role']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>
