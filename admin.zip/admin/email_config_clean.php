<?php
/**
 * Configuración de Email para Sistema de Invitaciones
 * Versión simplificada y funcional
 */

// === CONFIGURACIÓN BÁSICA ===
if (!defined('MAIL_FROM_EMAIL')) {
    define('MAIL_FROM_EMAIL', 'noreply@tuempresa.com');
}
if (!defined('MAIL_FROM_NAME')) {
    define('MAIL_FROM_NAME', 'Índice Producción');
}
if (!defined('MAIL_REPLY_TO')) {
    define('MAIL_REPLY_TO', 'soporte@tuempresa.com');
}

// === CONFIGURACIÓN SMTP (OPCIONAL) ===
// Descomenta y configura según tu proveedor de email

// Gmail / Google Workspace
/*
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USERNAME', 'tu-email@gmail.com');
define('SMTP_PASSWORD', 'tu-app-password'); // Usar App Password, no la contraseña normal
*/

// Outlook / Office 365
/*
define('SMTP_HOST', 'smtp.office365.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USERNAME', 'tu-email@outlook.com');
define('SMTP_PASSWORD', 'tu-contraseña');
*/

// Incluir funciones de email (solo una vez)
if (!function_exists('sendInvitationEmail')) {
    require_once __DIR__ . '/email_functions.php';
}
?>
