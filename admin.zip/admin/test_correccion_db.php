<?php
require_once '../config.php';

echo "<h2>🔧 Test de Corrección - Variable \$db</h2>";

try {
    echo "<div style='padding: 10px; background: #e7f3ff; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>✅ Test 1: Conexión a Base de Datos</h3>";
    
    $db = getDB();
    if ($db) {
        echo "<p>✅ Conexión establecida correctamente</p>";
        echo "<p>Tipo de objeto: " . get_class($db) . "</p>";
    } else {
        echo "<p>❌ Error en conexión</p>";
    }
    echo "</div>";

    echo "<div style='padding: 10px; background: #f0f9ff; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>✅ Test 2: Verificar Variables de Sesión</h3>";
    
    if (isset($_SESSION['user_id'])) {
        echo "<p>✅ Usuario loggeado: " . $_SESSION['user_name'] . " (ID: " . $_SESSION['user_id'] . ")</p>";
        
        // Test de consulta de empresas
        $stmt = $db->prepare("
            SELECT c.id, c.name, uc.role 
            FROM companies c 
            INNER JOIN user_companies uc ON c.id = uc.company_id 
            WHERE uc.user_id = ? AND uc.status = 'active'
            ORDER BY c.name
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $companies = $stmt->fetchAll();
        
        echo "<p>✅ Empresas encontradas: " . count($companies) . "</p>";
        
        if ($companies) {
            echo "<h4>Empresas del usuario:</h4>";
            echo "<ul>";
            foreach ($companies as $company) {
                echo "<li>ID: {$company['id']} - {$company['name']} ({$company['role']})</li>";
            }
            echo "</ul>";
        }
        
    } else {
        echo "<p>❌ No hay usuario loggeado</p>";
    }
    echo "</div>";

    echo "<div style='padding: 10px; background: #f0fdf4; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>✅ Test 3: Variables de Empresa Activa</h3>";
    
    $current_company_id = $_SESSION['current_company_id'] ?? $_SESSION['company_id'] ?? null;
    echo "<p>Current Company ID: " . ($current_company_id ?: 'No definido') . "</p>";
    echo "<p>Company ID (session): " . ($_SESSION['company_id'] ?? 'No definido') . "</p>";
    echo "<p>Current Company ID (session): " . ($_SESSION['current_company_id'] ?? 'No definido') . "</p>";
    echo "<p>Current Role: " . ($_SESSION['current_role'] ?? 'No definido') . "</p>";
    
    echo "</div>";

    echo "<div style='padding: 10px; background: #fefce8; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>✅ Test 4: Simulación de Cambio de Empresa</h3>";
    
    if (!empty($_GET['test_switch']) && $companies) {
        $test_company_id = (int)$_GET['test_switch'];
        echo "<p>🔄 Probando cambio a empresa ID: $test_company_id</p>";
        
        // Verificar acceso
        $stmt = $db->prepare("
            SELECT c.id, c.name, uc.role 
            FROM companies c 
            INNER JOIN user_companies uc ON c.id = uc.company_id 
            WHERE c.id = ? AND uc.user_id = ? AND uc.status = 'active'
        ");
        $stmt->execute([$test_company_id, $_SESSION['user_id']]);
        $company_access = $stmt->fetch();
        
        if ($company_access) {
            echo "<p>✅ Acceso verificado: {$company_access['name']} (rol: {$company_access['role']})</p>";
            echo "<p>🔗 <a href='?test_switch={$test_company_id}&apply=1'>Aplicar cambio de empresa</a></p>";
            
            if (!empty($_GET['apply'])) {
                $_SESSION['current_company_id'] = $test_company_id;
                $_SESSION['company_id'] = $test_company_id;
                $_SESSION['current_role'] = $company_access['role'];
                
                echo "<p>✅ Cambio aplicado. <a href='?'>Actualizar página</a></p>";
            }
        } else {
            echo "<p>❌ Sin acceso a empresa ID: $test_company_id</p>";
        }
    } else {
        if ($companies) {
            echo "<p>Probar cambio de empresa:</p>";
            echo "<ul>";
            foreach ($companies as $company) {
                $active = ($company['id'] == $current_company_id) ? ' (ACTIVA)' : '';
                echo "<li><a href='?test_switch={$company['id']}'>{$company['name']}</a>$active</li>";
            }
            echo "</ul>";
        }
    }
    
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='padding: 10px; background: #fef2f2; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>❌ Error en Test</h3>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "<p>Archivo: " . $e->getFile() . "</p>";
    echo "<p>Línea: " . $e->getLine() . "</p>";
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='../companies/'>🔙 Volver a Companies</a></p>";
echo "<p><a href='sistema_selector_empresas_completo.php'>📊 Dashboard Completo</a></p>";
?>
