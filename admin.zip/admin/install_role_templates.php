<?php
/*
 * Script para instalar plantillas de roles faltantes
 * Ejecutar solo una vez para completar la instalación
 */

require_once 'db_connection.php';

try {
    $mysqli = createPermissionsConnection();
    
    echo "🔧 Instalando plantillas de roles...\n\n";
    
    // Verificar si ya existen plantillas
    $check = $mysqli->query("SELECT COUNT(*) as count FROM role_permission_templates");
    $existing_count = $check->fetch_assoc()['count'];
    
    if ($existing_count > 0) {
        echo "✅ Ya existen $existing_count plantillas de roles instaladas.\n";
        echo "🔄 Actualizando plantillas existentes...\n\n";
        
        // Limpiar plantillas existentes para reinstalar
        $mysqli->query("DELETE FROM role_permission_templates");
    }
    
    // Plantillas de roles
    $role_templates = [
        // SuperAdmin - Acceso total
        ['superadmin', 'orders', 1, 1, 1, 1, 1],
        ['superadmin', 'maintenance', 1, 1, 1, 1, 1],
        ['superadmin', 'customer_service', 1, 1, 1, 1, 1],
        ['superadmin', 'expenses', 1, 1, 1, 1, 1],
        ['superadmin', 'transfers', 1, 1, 1, 1, 1],
        ['superadmin', 'reports', 1, 1, 1, 1, 1],
        ['superadmin', 'users', 1, 1, 1, 1, 1],
        ['superadmin', 'companies', 1, 1, 1, 1, 1],
        ['superadmin', 'settings', 1, 1, 1, 1, 1],
        
        // Admin - Amplio pero sin administración de empresas
        ['admin', 'orders', 1, 1, 1, 1, 0],
        ['admin', 'maintenance', 1, 1, 1, 1, 0],
        ['admin', 'customer_service', 1, 1, 1, 1, 0],
        ['admin', 'expenses', 1, 1, 1, 1, 0],
        ['admin', 'transfers', 1, 1, 1, 1, 0],
        ['admin', 'reports', 1, 1, 1, 0, 0],
        ['admin', 'users', 1, 1, 1, 0, 0],
        ['admin', 'companies', 1, 0, 0, 0, 0],
        ['admin', 'settings', 1, 0, 1, 0, 0],
        
        // Moderator - Supervisión
        ['moderator', 'orders', 1, 1, 1, 0, 0],
        ['moderator', 'maintenance', 1, 1, 1, 0, 0],
        ['moderator', 'customer_service', 1, 1, 1, 0, 0],
        ['moderator', 'expenses', 1, 0, 1, 0, 0],
        ['moderator', 'transfers', 1, 0, 1, 0, 0],
        ['moderator', 'reports', 1, 0, 0, 0, 0],
        ['moderator', 'users', 1, 0, 0, 0, 0],
        ['moderator', 'companies', 1, 0, 0, 0, 0],
        ['moderator', 'settings', 1, 0, 0, 0, 0],
        
        // User - Solo lectura básica
        ['user', 'orders', 1, 0, 0, 0, 0],
        ['user', 'maintenance', 1, 0, 0, 0, 0],
        ['user', 'customer_service', 1, 0, 0, 0, 0],
        ['user', 'expenses', 1, 0, 0, 0, 0],
        ['user', 'transfers', 1, 0, 0, 0, 0],
        ['user', 'reports', 1, 0, 0, 0, 0],
        ['user', 'users', 0, 0, 0, 0, 0],
        ['user', 'companies', 0, 0, 0, 0, 0],
        ['user', 'settings', 0, 0, 0, 0, 0]
    ];
    
    $success_count = 0;
    $stmt = $mysqli->prepare("INSERT INTO role_permission_templates (role_name, module_id, can_view, can_create, can_edit, can_delete, can_admin) VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    foreach ($role_templates as $template) {
        $stmt->bind_param("ssiiiiii", $template[0], $template[1], $template[2], $template[3], $template[4], $template[5], $template[6]);
        if ($stmt->execute()) {
            $success_count++;
        }
    }
    
    echo "✅ Instaladas $success_count plantillas de roles\n";
    
    // Verificar instalación
    $roles_check = $mysqli->query("SELECT role_name, COUNT(*) as modules FROM role_permission_templates GROUP BY role_name");
    echo "\n📋 Plantillas instaladas:\n";
    while ($role = $roles_check->fetch_assoc()) {
        echo "   🎭 {$role['role_name']}: {$role['modules']} módulos\n";
    }
    
    echo "\n🎉 ¡Instalación de plantillas completada!\n";
    echo "✨ El sistema de permisos está listo para usar.\n";
    
    $mysqli->close();
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
