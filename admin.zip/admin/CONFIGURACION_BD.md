# 🔧 Configuración de Base de Datos para el Servidor

## ❌ Error de Configuración

Si ves el error:
```
SQLSTATE[HY000] [1045] Access denied for user ''@'localhost' (using password: NO)
```

Significa que el sistema no puede acceder a los datos de la base de datos.

## ✅ Solución

### Opción 1: Archivo de Configuración Manual (Recomendado)

1. **Edita el archivo `admin/db_config_server.php`**:
   ```php
   <?php
   return [
       'host' => 'localhost',           // Tu servidor de BD
       'database' => 'tu_bd_nombre',    // Nombre de tu base de datos  
       'username' => 'tu_usuario',      // Usuario de BD
       'password' => 'tu_contraseña'    // Contraseña de BD
   ];
   ?>
   ```

2. **Ejemplo con datos reales**:
   ```php
   <?php
   return [
       'host' => 'localhost',
       'database' => 'indice_saas',
       'username' => 'root', 
       'password' => 'mi_password_123'
   ];
   ?>
   ```

3. **Ejecuta la instalación**:
   - Ve a `admin/install_permissions_fase2.php`
   - El sistema detectará automáticamente tu configuración

### Opción 2: Variables de Entorno

1. **Crea un archivo `.env` en la raíz**:
   ```env
   DB_HOST=localhost
   DB_NAME=tu_base_datos
   DB_USER=tu_usuario
   DB_PASS=tu_contraseña
   ```

### Opción 3: Configuración Directa en config.php

1. **Modifica `config.php`** para incluir:
   ```php
   $config = [
       'host' => 'localhost',
       'database' => 'tu_bd',
       'username' => 'tu_usuario', 
       'password' => 'tu_contraseña'
   ];
   ```

## 🔍 Verificar Configuración

1. Ve a `admin/check_permissions_status.php`
2. Verifica que aparezcan tus datos de BD
3. Si ves "VACÍA" en algún campo, revisa la configuración

## 🚀 Pasos Siguientes

Una vez solucionado el error de configuración:

1. ✅ **Instalar**: `admin/install_permissions_fase2.php`
2. ✅ **Verificar**: `admin/check_permissions_status.php`  
3. ✅ **Usar**: `admin/permisos.php`

## 🔒 Seguridad

- ⚠️ **NO** subas archivos con contraseñas a repositorios públicos
- ✅ Usa `.env` para datos sensibles
- ✅ Agrega `db_config_server.php` a `.gitignore`

---

**¿Necesitas ayuda?** Verifica estos archivos en orden:
1. `admin/db_config_server.php` (crear/editar)
2. `.env` (si usas variables de entorno)
3. `config.php` (configuración base)
