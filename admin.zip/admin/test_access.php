<?php
require_once '../config.php';

// Procesar establecimiento de empresa PRIMERO
if (isset($_GET['set_company'])) {
    $company_id = intval($_GET['set_company']);
    
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT id, name FROM companies WHERE id = ? AND status = 'active'");
        $stmt->execute([$company_id]);
        $company = $stmt->fetch();
        
        if ($company) {
            $_SESSION['current_company_id'] = $company['id'];
            $_SESSION['current_company_name'] = $company['name'];
            $success_message = "✅ Empresa establecida: " . htmlspecialchars($company['name']);
        } else {
            $error_message = "❌ Empresa no encontrada";
        }
    } catch (Exception $e) {
        $error_message = "❌ Error: " . $e->getMessage();
    }
    
    // Redirigir para limpiar la URL
    header("Location: test_access.php");
    exit;
}

// Test de acceso al panel de administración

echo "<h1>🔧 Test Panel Administración</h1>";

// Mostrar mensajes si existen
if (isset($success_message)) {
    echo "<div style='background: #d4edda; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
    echo $success_message;
    echo "</div>";
}
if (isset($error_message)) {
    echo "<div style='background: #f8d7da; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
    echo $error_message;
    echo "</div>";
}

// Verificar autenticación
if (!checkAuth()) {
    echo "<p>❌ No autenticado</p>";
    exit;
}

echo "<p>✅ Usuario autenticado: " . $_SESSION['user_name'] . "</p>";
echo "<p>✅ Rol actual: " . ($_SESSION['current_role'] ?? 'No definido') . "</p>";

// Verificar roles
echo "<h2>Verificación de Roles:</h2>";
echo "<p>¿Es root? " . (checkRole(['root']) ? "✅ Sí" : "❌ No") . "</p>";
echo "<p>¿Es superadmin? " . (checkRole(['superadmin']) ? "✅ Sí" : "❌ No") . "</p>";
echo "<p>¿Es admin? " . (checkRole(['admin']) ? "✅ Sí" : "❌ No") . "</p>";
echo "<p>¿Puede acceder al panel? " . (checkRole(['root', 'superadmin', 'admin']) ? "✅ Sí" : "❌ No") . "</p>";

// Mostrar empresas disponibles
echo "<h2>Empresas Disponibles:</h2>";
try {
    $pdo = getDB();
    
    // Para usuarios root, mostrar todas las empresas
    if (checkRole(['root'])) {
        $stmt = $pdo->prepare("SELECT id, name FROM companies WHERE status = 'active' ORDER BY name");
        $stmt->execute();
    } else {
        // Para otros usuarios, mostrar solo sus empresas
        $stmt = $pdo->prepare("
            SELECT DISTINCT c.id, c.name 
            FROM companies c
            INNER JOIN user_companies uc ON c.id = uc.company_id
            WHERE c.status = 'active' AND uc.user_id = ? AND uc.status = 'active'
            ORDER BY c.name
        ");
        $stmt->execute([$_SESSION['user_id']]);
    }
    
    $companies = $stmt->fetchAll();
    
    if ($companies) {
        echo "<ul>";
        foreach ($companies as $company) {
            $setCompanyUrl = "?set_company=" . $company['id'];
            echo "<li>";
            echo htmlspecialchars($company['name']) . " (ID: " . $company['id'] . ")";
            echo " - <a href='$setCompanyUrl'>Establecer como activa</a>";
            echo "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>❌ No se encontraron empresas</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

// Mostrar estado actual de la sesión
echo "<h2>Estado Actual de la Sesión:</h2>";
echo "<p>Current Company ID: " . ($_SESSION['current_company_id'] ?? 'No definido') . "</p>";
echo "<p>Company ID (fallback): " . ($_SESSION['company_id'] ?? 'No definido') . "</p>";
echo "<p>Company Name: " . ($_SESSION['current_company_name'] ?? 'No definido') . "</p>";

// Usar company_id como fallback si current_company_id no está definido
$active_company_id = $_SESSION['current_company_id'] ?? $_SESSION['company_id'] ?? null;

// Enlaces de prueba
if ($active_company_id) {
    echo "<h2>Enlaces de Prueba:</h2>";
    echo "<p>Usando Company ID: $active_company_id</p>";
    echo "<ul>";
    echo "<li><a href='usuarios.php?company_id=$active_company_id' target='_blank'>🧑‍💼 Usuarios</a></li>";
    echo "<li><a href='permisos.php?company_id=$active_company_id' target='_blank'>🔐 Permisos</a></li>";
    echo "<li><a href='roles.php?company_id=$active_company_id' target='_blank'>👥 Roles</a></li>";
    echo "</ul>";
} else {
    echo "<p>⚠️ Establece una empresa primero para probar los enlaces del panel</p>";
}

echo "<br><a href='../companies/simple_test.php'>🔙 Volver al test</a>";
?>
