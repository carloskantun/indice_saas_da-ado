-- Crear tabla user_invitations faltante
CREATE TABLE IF NOT EXISTS `user_invitations` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `email` varchar(255) NOT NULL,
    `company_id` int(11) NOT NULL,
    `unit_id` int(11) DEFAULT NULL,
    `business_id` int(11) DEFAULT NULL,
    `role` enum('superadmin','admin','moderator','user') NOT NULL DEFAULT 'user',
    `token` varchar(64) NOT NULL,
    `status` enum('pending','accepted','expired','cancelled') NOT NULL DEFAULT 'pending',
    `sent_by` int(11) NOT NULL,
    `sent_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `expiration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `accepted_date` timestamp NULL DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_pending_invitation` (`email`, `company_id`, `status`),
    KEY `idx_token` (`token`),
    KEY `idx_company_status` (`company_id`, `status`),
    KEY `idx_expiration` (`expiration_date`),
    FOREIGN KEY (`company_id`) REFERENCES `companies`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`sent_by`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Trigger para establecer automáticamente la fecha de expiración (48 horas después del envío)
DELIMITER $$
CREATE TRIGGER IF NOT EXISTS `set_expiration_date` 
BEFORE INSERT ON `user_invitations`
FOR EACH ROW 
BEGIN
    IF NEW.expiration_date = NEW.sent_date THEN
        SET NEW.expiration_date = DATE_ADD(NEW.sent_date, INTERVAL 48 HOUR);
    END IF;
END$$
DELIMITER ;
