<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completar Instalación - Permisos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-warning text-dark text-center">
                        <h4><i class="fas fa-exclamation-triangle"></i> Completar Instalación</h4>
                    </div>
                    <div class="card-body text-center">
                        <p class="mb-4">Faltan las plantillas de roles por instalar. Haz clic en el botón para completar la instalación:</p>
                        
                        <button class="btn btn-primary btn-lg" onclick="installTemplates()">
                            <i class="fas fa-download"></i> Instalar Plantillas de Roles
                        </button>
                        
                        <div id="result" class="mt-4"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function installTemplates() {
            const button = document.querySelector('button');
            const result = document.getElementById('result');
            
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Instalando...';
            
            try {
                const response = await fetch('controller.php?action=install_role_templates');
                const data = await response.json();
                
                if (data.success) {
                    result.innerHTML = `
                        <div class="alert alert-success">
                            <h5><i class="fas fa-check-circle"></i> ¡Instalación Completada!</h5>
                            <p>${data.message}</p>
                            <a href="permissions_management.php" class="btn btn-success">
                                <i class="fas fa-arrow-right"></i> Ir a Gestión de Permisos
                            </a>
                        </div>
                    `;
                } else {
                    result.innerHTML = `
                        <div class="alert alert-danger">
                            <h5><i class="fas fa-times-circle"></i> Error</h5>
                            <p>${data.message}</p>
                        </div>
                    `;
                    button.disabled = false;
                    button.innerHTML = '<i class="fas fa-download"></i> Instalar Plantillas de Roles';
                }
            } catch (error) {
                result.innerHTML = `
                    <div class="alert alert-danger">
                        <h5><i class="fas fa-times-circle"></i> Error de Conexión</h5>
                        <p>No se pudo completar la instalación. Verifica tu conexión.</p>
                    </div>
                `;
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-download"></i> Instalar Plantillas de Roles';
            }
        }
    </script>
</body>
</html>
