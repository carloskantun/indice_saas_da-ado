<?php
// Test de nomenclatura y localización
require_once 'config.php';

echo "🌍 **REPORTE DE NORMALIZACIÓN DEL SISTEMA**\n";
echo "==========================================\n\n";

try {
    $db = getDB();
    
    echo "1. 📊 **ESTRUCTURA DE BASE DE DATOS**\n";
    echo "-------------------------------------\n";
    
    // Test estructura companies
    $stmt = $db->query("DESCRIBE companies");
    $columns = $stmt->fetchAll();
    
    $has_name = false;
    $has_nombre = false;
    
    foreach ($columns as $column) {
        if ($column['Field'] === 'name') $has_name = true;
        if ($column['Field'] === 'nombre') $has_nombre = true;
    }
    
    echo "   Companies table:\n";
    echo "   - Column 'name': " . ($has_name ? '✅ EXISTS (English)' : '❌ MISSING') . "\n";
    echo "   - Column 'nombre': " . ($has_nombre ? '⚠️  EXISTS (Spanish)' : '✅ NOT FOUND (Good)') . "\n";
    
    if ($has_name && !$has_nombre) {
        echo "   🎯 **CORRECTO**: Base de datos usa nomenclatura en inglés\n";
    } elseif (!$has_name && $has_nombre) {
        echo "   ⚠️  **ATENCIÓN**: Base de datos usa nomenclatura en español\n";
    } elseif ($has_name && $has_nombre) {
        echo "   🚨 **PROBLEMA**: Base de datos tiene AMBAS columnas\n";
    }
    
    echo "\n2. 🔍 **TEST DE QUERIES**\n";
    echo "------------------------\n";
    
    // Test query companies
    try {
        $column_to_use = $has_name ? 'name' : 'nombre';
        $stmt = $db->query("SELECT id, $column_to_use FROM companies LIMIT 1");
        $result = $stmt->fetch();
        echo "   ✅ Query SELECT companies.$column_to_use works\n";
        if ($result) {
            echo "   📄 Sample: " . $result[$column_to_use] . "\n";
        }
    } catch (Exception $e) {
        echo "   ❌ Query failed: " . $e->getMessage() . "\n";
    }
    
    echo "\n3. 🌐 **SISTEMA DE LOCALIZACIÓN**\n";
    echo "--------------------------------\n";
    
    // Test lang files
    $lang_es_exists = file_exists(__DIR__ . '/lang/es.php');
    $lang_en_exists = file_exists(__DIR__ . '/lang/en.php');
    
    echo "   - lang/es.php: " . ($lang_es_exists ? '✅ EXISTS' : '❌ MISSING') . "\n";
    echo "   - lang/en.php: " . ($lang_en_exists ? '✅ EXISTS' : '❌ MISSING') . "\n";
    
    if ($lang_es_exists) {
        $lang_es = include __DIR__ . '/lang/es.php';
        $auth_keys = [
            'complete_required_fields',
            'email_already_registered', 
            'invalid_invitation_token',
            'free_account_created_success',
            'superadmin_account_created',
            'system_error'
        ];
        
        echo "\n   📋 **Claves de autenticación en es.php:**\n";
        foreach ($auth_keys as $key) {
            $exists = isset($lang_es[$key]);
            echo "      - $key: " . ($exists ? '✅' : '❌') . "\n";
        }
    }
    
    echo "\n4. 📝 **ARCHIVOS DE CÓDIGO**\n";
    echo "---------------------------\n";
    
    // Check key files for hardcoded Spanish
    $files_to_check = [
        'auth/register.php',
        'companies/invitations.php',
        'notifications/index.php'
    ];
    
    foreach ($files_to_check as $file) {
        if (file_exists($file)) {
            $content = file_get_contents($file);
            
            // Check for hardcoded Spanish strings
            $spanish_patterns = [
                'Este correo electrónico',
                'Token de invitación',
                'Cuenta gratuita creada',
                'Plan seleccionado no válido'
            ];
            
            $hardcoded_found = 0;
            foreach ($spanish_patterns as $pattern) {
                if (strpos($content, $pattern) !== false) {
                    $hardcoded_found++;
                }
            }
            
            // Check for proper lang usage
            $lang_usage = substr_count($content, '$lang[');
            
            echo "   📄 $file:\n";
            echo "      - Hardcoded Spanish strings: " . ($hardcoded_found > 0 ? "⚠️  $hardcoded_found found" : "✅ None") . "\n";
            echo "      - Lang array usage: " . ($lang_usage > 0 ? "✅ $lang_usage times" : "❌ Not used") . "\n";
        }
    }
    
    echo "\n5. 🎯 **RECOMENDACIONES**\n";
    echo "-------------------------\n";
    
    if ($has_name && !$has_nombre) {
        echo "   ✅ Database: Uses English column names (GOOD)\n";
    } else {
        echo "   ⚠️  Database: Review column naming convention\n";
    }
    
    if ($lang_es_exists && $lang_en_exists) {
        echo "   ✅ Localization: Both ES and EN files available\n";
    } else {
        echo "   ⚠️  Localization: Missing language files\n";
    }
    
    echo "\n📋 **SIGUIENTE PASOS SUGERIDOS:**\n";
    echo "1. Usar siempre \$lang['key'] en lugar de strings hardcodeados\n";
    echo "2. Mantener nomenclatura de BD en inglés (companies.name)\n";
    echo "3. Textos de UI en archivos lang/ según idioma del usuario\n";
    echo "4. Variables y funciones en inglés, UI multiidioma\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
