<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Notificaciones - Final</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .section { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        .success { color: #155724; background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .error { color: #721c24; background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .info { color: #0c5460; background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .warning { color: #856404; background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 8px; border: 1px solid #ddd; text-align: left; }
        th { background: #f8f9fa; }
        .btn { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; margin: 5px; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>

<h1>🔧 Test Final - Sistema de Notificaciones</h1>

<?php
require_once 'config.php';
require_once 'includes/notifications.php';

try {
    $db = getDB();
    
    echo '<div class="section">';
    echo '<h2>1. ✅ Verificación de Configuración</h2>';
    
    // Verificar tabla notifications
    $stmt = $db->query("SHOW TABLES LIKE 'notifications'");
    $table_exists = $stmt->fetch();
    
    if ($table_exists) {
        echo '<div class="success">✅ Tabla notifications existe</div>';
        
        // Contar registros
        $stmt = $db->query("SELECT COUNT(*) FROM notifications");
        $count = $stmt->fetchColumn();
        echo "<div class='info'>📊 Total de notificaciones: $count</div>";
        
    } else {
        echo '<div class="error">❌ Tabla notifications no existe</div>';
        
        // Intentar crearla
        $created = createNotificationsTable();
        if ($created) {
            echo '<div class="success">✅ Tabla notifications creada exitosamente</div>';
        } else {
            echo '<div class="error">❌ Error creando tabla notifications</div>';
        }
    }
    
    echo '</div>';
    
    echo '<div class="section">';
    echo '<h2>2. 🧪 Test de Creación de Notificación</h2>';
    
    // Buscar datos para hacer test
    $stmt = $db->query("SELECT id, email FROM users LIMIT 1");
    $user = $stmt->fetch();
    
    $stmt = $db->query("SELECT id, name FROM companies LIMIT 1");
    $company = $stmt->fetch();
    
    if ($user && $company) {
        echo "<div class='info'>Creando notificación de prueba...<br>";
        echo "Usuario: {$user['email']}<br>";
        echo "Empresa: {$company['name']}</div>";
        
        $notification_id = createInvitationNotification(
            $company['id'],
            $user['id'],
            'test@example.com',
            2,
            'test_system'
        );
        
        if ($notification_id) {
            echo '<div class="success">✅ Notificación creada con ID: ' . $notification_id . '</div>';
            
            // Verificar que se creó correctamente
            $stmt = $db->prepare("SELECT * FROM notifications WHERE id = ?");
            $stmt->execute([$notification_id]);
            $notification = $stmt->fetch();
            
            if ($notification) {
                echo '<table>';
                echo '<tr><th>Campo</th><th>Valor</th></tr>';
                echo '<tr><td>ID</td><td>' . $notification['id'] . '</td></tr>';
                echo '<tr><td>Company ID</td><td>' . $notification['company_id'] . '</td></tr>';
                echo '<tr><td>User ID</td><td>' . $notification['user_id'] . '</td></tr>';
                echo '<tr><td>Type</td><td>' . $notification['type'] . '</td></tr>';
                echo '<tr><td>Title</td><td>' . htmlspecialchars($notification['title']) . '</td></tr>';
                echo '<tr><td>Status</td><td>' . $notification['status'] . '</td></tr>';
                echo '<tr><td>Created</td><td>' . $notification['created_at'] . '</td></tr>';
                echo '</table>';
                
                // Limpiar - eliminar la notificación de prueba
                $stmt = $db->prepare("DELETE FROM notifications WHERE id = ?");
                $stmt->execute([$notification_id]);
                echo '<div class="warning">🧹 Notificación de prueba eliminada</div>';
            }
            
        } else {
            echo '<div class="error">❌ Error creando notificación de prueba</div>';
        }
        
    } else {
        echo '<div class="warning">⚠️ No hay usuarios o empresas para hacer la prueba</div>';
    }
    
    echo '</div>';
    
    echo '<div class="section">';
    echo '<h2>3. 📊 Estado Actual del Sistema</h2>';
    
    // Estadísticas actuales
    $stmt = $db->query("SELECT COUNT(*) FROM notifications");
    $total_notifications = $stmt->fetchColumn();
    
    $stmt = $db->query("SELECT COUNT(*) FROM user_invitations");
    $total_invitations = $stmt->fetchColumn();
    
    echo '<table>';
    echo '<tr><th>Métrica</th><th>Valor</th></tr>';
    echo '<tr><td>Total Notificaciones</td><td>' . $total_notifications . '</td></tr>';
    echo '<tr><td>Total Invitaciones</td><td>' . $total_invitations . '</td></tr>';
    echo '</table>';
    
    if ($total_notifications > 0) {
        echo '<h3>Últimas Notificaciones:</h3>';
        $stmt = $db->query("
            SELECT n.*, u.email as user_email, c.name as company_name
            FROM notifications n
            LEFT JOIN users u ON n.user_id = u.id
            LEFT JOIN companies c ON n.company_id = c.id
            ORDER BY n.created_at DESC
            LIMIT 5
        ");
        $notifications = $stmt->fetchAll();
        
        echo '<table>';
        echo '<tr><th>ID</th><th>Usuario</th><th>Empresa</th><th>Tipo</th><th>Estado</th><th>Fecha</th></tr>';
        foreach ($notifications as $n) {
            echo '<tr>';
            echo '<td>' . $n['id'] . '</td>';
            echo '<td>' . htmlspecialchars($n['user_email']) . '</td>';
            echo '<td>' . htmlspecialchars($n['company_name']) . '</td>';
            echo '<td>' . $n['type'] . '</td>';
            echo '<td>' . $n['status'] . '</td>';
            echo '<td>' . $n['created_at'] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
    
    echo '</div>';
    
} catch (Exception $e) {
    echo '<div class="error">❌ Error: ' . $e->getMessage() . '</div>';
}
?>

<div class="section">
    <h2>🎯 Acciones de Prueba</h2>
    <p>Ahora puedes probar el sistema completo:</p>
    
    <a href="companies/invitations.php" class="btn">👥 Crear Nueva Invitación</a>
    <a href="notifications/" class="btn">📧 Ver Notificaciones</a>
    <a href="debug_notifications.php" class="btn">🔍 Debug Completo</a>
    
    <h3>🔄 Flujo de Prueba Recomendado:</h3>
    <ol>
        <li><strong>Crear invitación:</strong> Ve a Gestión de Invitaciones y crea una nueva invitación</li>
        <li><strong>Verificar notificación:</strong> Revisa que se creó la notificación correspondiente</li>
        <li><strong>Ver panel:</strong> Ve al panel de notificaciones para verificar que aparece</li>
        <li><strong>Probar aceptación:</strong> Si invitas a un usuario existente, prueba aceptar la invitación</li>
    </ol>
</div>

</body>
</html>
