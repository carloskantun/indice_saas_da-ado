<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Companies - Test Minimal</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; background: #f8f9fa; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #28a745; background: #d4edda; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .error { color: #dc3545; background: #f8d7da; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .info { color: #0c5460; background: #d1ecf1; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .btn { background: #007bff; color: white; padding: 12px 20px; text-decoration: none; border-radius: 5px; margin: 10px 5px; display: inline-block; }
        .btn:hover { background: #0056b3; color: white; }
        .btn-success { background: #28a745; }
        .btn-warning { background: #ffc107; color: #212529; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background: #f8f9fa; font-weight: bold; }
        .company-card { background: #f8f9fa; padding: 20px; margin: 15px 0; border-radius: 8px; border: 1px solid #e9ecef; }
    </style>
</head>
<body>

<div class="container">
    <h1>🏢 Companies - Versión Test</h1>
    <p>Esta es una versión simplificada para verificar que la lógica básica funciona.</p>

    <?php
    // Configuración de errores
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    $error = null;
    $companies = [];
    $user_name = 'Usuario';

    try {
        // Cargar configuración
        require_once '../config.php';
        
        echo '<div class="success">✅ Configuración cargada correctamente</div>';

        // Verificar autenticación
        if (!checkAuth()) {
            echo '<div class="error">❌ Usuario no autenticado</div>';
            echo '<div class="info"><a href="../auth/" class="btn">🔐 Iniciar Sesión</a></div>';
            echo '</div></body></html>';
            exit;
        }

        echo '<div class="success">✅ Usuario autenticado</div>';

        $user_id = $_SESSION['user_id'];
        $user_name = $_SESSION['user_name'] ?? 'Usuario';
        
        echo '<div class="info">👤 Usuario: ' . htmlspecialchars($user_name) . ' (ID: ' . $user_id . ')</div>';

        // Conectar a base de datos
        $db = getDB();
        echo '<div class="success">✅ Conexión a base de datos establecida</div>';

        // Obtener empresas del usuario
        $stmt = $db->prepare("
            SELECT c.id, c.name, c.description, uc.role, uc.status,
                   uc.fecha_registro as joined_date
            FROM companies c 
            INNER JOIN user_companies uc ON c.id = uc.company_id 
            WHERE uc.user_id = ? 
            ORDER BY c.name ASC
        ");
        $stmt->execute([$user_id]);
        $companies = $stmt->fetchAll();

        echo '<div class="success">✅ Empresas cargadas: ' . count($companies) . '</div>';

        // Manejar cambio de empresa
        if (isset($_GET['switch_company']) && !empty($_GET['switch_company'])) {
            $new_company_id = (int)$_GET['switch_company'];
            
            // Verificar acceso
            $has_access = false;
            foreach ($companies as $company) {
                if ($company['id'] == $new_company_id) {
                    $has_access = true;
                    break;
                }
            }
            
            if ($has_access) {
                $_SESSION['company_id'] = $new_company_id;
                $_SESSION['current_company_id'] = $new_company_id;
                echo '<div class="success">✅ Empresa cambiada a ID: ' . $new_company_id . '</div>';
                
                // Recargar página sin parámetro
                echo '<script>window.location.href = "companies_test.php";</script>';
            } else {
                echo '<div class="error">❌ No tienes acceso a esa empresa</div>';
            }
        }

        // Mostrar empresa actual
        $current_company_id = $_SESSION['company_id'] ?? $_SESSION['current_company_id'] ?? null;
        if ($current_company_id) {
            $current_company = null;
            foreach ($companies as $company) {
                if ($company['id'] == $current_company_id) {
                    $current_company = $company;
                    break;
                }
            }
            
            if ($current_company) {
                echo '<div class="info">🏢 Empresa actual: ' . htmlspecialchars($current_company['name']) . '</div>';
            }
        }

    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
        echo '<div class="error">❌ ' . htmlspecialchars($error) . '</div>';
        error_log("Error en companies test: " . $e->getMessage());
    }
    ?>

    <?php if (count($companies) > 0): ?>
        <h2>📋 Tus Empresas</h2>
        
        <table>
            <thead>
                <tr>
                    <th>Empresa</th>
                    <th>Descripción</th>
                    <th>Tu Rol</th>
                    <th>Estado</th>
                    <th>Fecha Ingreso</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($companies as $company): ?>
                    <tr style="<?php echo ($current_company_id == $company['id']) ? 'background-color: #e3f2fd;' : ''; ?>">
                        <td>
                            <strong><?php echo htmlspecialchars($company['name']); ?></strong>
                            <?php if ($current_company_id == $company['id']): ?>
                                <span style="color: #007bff; font-weight: bold;"> (Actual)</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($company['description'] ?? 'Sin descripción'); ?></td>
                        <td>
                            <span style="background: #007bff; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">
                                <?php echo strtoupper($company['role']); ?>
                            </span>
                        </td>
                        <td>
                            <span style="color: <?php echo $company['status'] === 'active' ? '#28a745' : '#dc3545'; ?>;">
                                <?php echo ucfirst($company['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('d/m/Y', strtotime($company['joined_date'])); ?></td>
                        <td>
                            <?php if ($current_company_id != $company['id']): ?>
                                <a href="?switch_company=<?php echo $company['id']; ?>" class="btn" style="font-size: 12px; padding: 5px 10px;">
                                    🔄 Cambiar
                                </a>
                            <?php endif; ?>
                            
                            <?php if ($company['id'] == $current_company_id): ?>
                                <a href="invitations.php" class="btn btn-success" style="font-size: 12px; padding: 5px 10px;">
                                    👥 Invitaciones
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h2>🎯 Acciones Rápidas</h2>
        <div style="margin: 20px 0;">
            <a href="invitations.php" class="btn btn-success">👥 Gestionar Invitaciones</a>
            <a href="../notifications/" class="btn">📧 Ver Notificaciones</a>
            <a href="../" class="btn">🏠 Inicio</a>
            <a href="index.php" class="btn btn-warning">🔄 Companies Original</a>
        </div>

    <?php else: ?>
        <div class="info">
            <h2>🏢 No perteneces a ninguna empresa</h2>
            <p>Parece que aún no formas parte de ninguna empresa. Contacta a un administrador para que te invite.</p>
            <a href="../auth/logout.php" class="btn">🚪 Cerrar Sesión</a>
        </div>
    <?php endif; ?>

    <hr style="margin: 40px 0;">
    
    <h2>🔧 Información de Debug</h2>
    <div class="info">
        <p><strong>Archivo:</strong> companies_test.php (versión simplificada)</p>
        <p><strong>Usuario ID:</strong> <?php echo $user_id ?? 'No definido'; ?></p>
        <p><strong>Empresa actual:</strong> <?php echo $current_company_id ?? 'No seleccionada'; ?></p>
        <p><strong>Total empresas:</strong> <?php echo count($companies); ?></p>
        <p><strong>Hora:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>

    <?php if ($error): ?>
        <div class="error">
            <h3>❌ Error Detectado</h3>
            <pre><?php echo htmlspecialchars($error); ?></pre>
        </div>
    <?php endif; ?>

</div>

</body>
</html>
