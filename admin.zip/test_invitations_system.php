<?php
// Test de sistema de invitaciones
require_once 'config.php';

echo "🎯 **TEST SISTEMA DE INVITACIONES**\n";
echo "===================================\n\n";

try {
    $db = getDB();
    
    echo "1. 📋 **VALIDACIÓN DE ESTRUCTURA**\n";
    echo "----------------------------------\n";
    
    // Test user_invitations table structure
    $stmt = $db->query("DESCRIBE user_invitations");
    $columns = $stmt->fetchAll();
    
    $required_columns = [
        'id', 'email', 'company_id', 'role', 'token', 'status', 
        'sent_by', 'sent_date', 'expiration_date', 'accepted_date'
    ];
    
    echo "   📄 user_invitations table:\n";
    foreach ($required_columns as $col) {
        $exists = false;
        foreach ($columns as $column) {
            if ($column['Field'] === $col) {
                $exists = true;
                break;
            }
        }
        echo "      - $col: " . ($exists ? '✅' : '❌') . "\n";
    }
    
    echo "\n2. 🧪 **TEST DE QUERIES**\n";
    echo "-------------------------\n";
    
    // Test 1: Invitations list query
    try {
        $stmt = $db->prepare("
            SELECT i.*, u.name as inviter_name 
            FROM user_invitations i
            LEFT JOIN users u ON i.sent_by = u.id
            WHERE i.company_id = ? 
            ORDER BY i.sent_date DESC
            LIMIT 5
        ");
        $stmt->execute([1]);
        $invitations = $stmt->fetchAll();
        echo "   ✅ Lista de invitaciones: " . count($invitations) . " encontradas\n";
    } catch (Exception $e) {
        echo "   ❌ Lista de invitaciones falló: " . $e->getMessage() . "\n";
    }
    
    // Test 2: User already member check
    try {
        $stmt = $db->prepare("
            SELECT u.id, u.name
            FROM users u 
            INNER JOIN user_companies uc ON u.id = uc.user_id 
            WHERE u.email = ? AND uc.company_id = ?
        ");
        $stmt->execute(['admin@indiceapp.com', 1]);
        echo "   ✅ Verificación de membresía funciona\n";
    } catch (Exception $e) {
        echo "   ❌ Verificación de membresía falló: " . $e->getMessage() . "\n";
    }
    
    // Test 3: Pending invitation check
    try {
        $stmt = $db->prepare("
            SELECT id FROM user_invitations 
            WHERE email = ? AND company_id = ? AND status = 'pending' AND expiration_date > NOW()
        ");
        $stmt->execute(['test@example.com', 1]);
        echo "   ✅ Verificación de invitación pendiente funciona\n";
    } catch (Exception $e) {
        echo "   ❌ Verificación de invitación pendiente falló: " . $e->getMessage() . "\n";
    }
    
    // Test 4: Token validation (auth process)
    try {
        $stmt = $db->prepare("
            SELECT * FROM user_invitations 
            WHERE token = ? AND email = ? AND status = 'pending' AND expiration_date > NOW()
        ");
        $stmt->execute(['test_token', 'test@example.com']);
        echo "   ✅ Validación de token funciona\n";
    } catch (Exception $e) {
        echo "   ❌ Validación de token falló: " . $e->getMessage() . "\n";
    }
    
    echo "\n3. 📊 **ESTADÍSTICAS**\n";
    echo "----------------------\n";
    
    // Mostrar estadísticas
    $stmt = $db->query("SELECT COUNT(*) FROM user_invitations");
    $total = $stmt->fetchColumn();
    echo "   📈 Total invitaciones: $total\n";
    
    $stmt = $db->query("SELECT COUNT(*) FROM user_invitations WHERE status = 'pending'");
    $pending = $stmt->fetchColumn();
    echo "   ⏳ Invitaciones pendientes: $pending\n";
    
    $stmt = $db->query("SELECT COUNT(*) FROM user_invitations WHERE status = 'accepted'");
    $accepted = $stmt->fetchColumn();
    echo "   ✅ Invitaciones aceptadas: $accepted\n";
    
    $stmt = $db->query("SELECT COUNT(*) FROM user_invitations WHERE expiration_date < NOW() AND status = 'pending'");
    $expired = $stmt->fetchColumn();
    echo "   ⌛ Invitaciones expiradas: $expired\n";
    
    echo "\n4. 🔍 **VALIDACIONES DE NEGOCIO**\n";
    echo "--------------------------------\n";
    
    // Buscar usuarios que ya están en el sistema
    $stmt = $db->query("
        SELECT u.email, u.name, COUNT(uc.company_id) as companies_count
        FROM users u
        LEFT JOIN user_companies uc ON u.id = uc.user_id
        GROUP BY u.id
        LIMIT 5
    ");
    $users = $stmt->fetchAll();
    
    echo "   👥 Usuarios en el sistema:\n";
    foreach ($users as $user) {
        echo "      - {$user['email']} ({$user['name']}) - {$user['companies_count']} empresa(s)\n";
    }
    
    echo "\n🎯 **RECOMENDACIONES**\n";
    echo "---------------------\n";
    echo "✅ La estructura de base de datos está correcta\n";
    echo "✅ Las queries principales funcionan\n";
    echo "✅ Sistema listo para invitar usuarios\n";
    
    if ($expired > 0) {
        echo "⚠️  Considera limpiar invitaciones expiradas periódicamente\n";
    }
    
    echo "\n💡 **PRÓXIMOS PASOS:**\n";
    echo "1. Probar invitación de usuario nuevo\n";
    echo "2. Probar invitación de usuario existente\n";
    echo "3. Verificar mensajes de error apropiados\n";
    
} catch (Exception $e) {
    echo "❌ Error de conexión: " . $e->getMessage() . "\n";
}
?>
